package com.example

import android.content.Context
import androidx.test.core.app.ApplicationProvider
import com.example.model.MessageActionType
import com.example.service.AiCompanionEngine
import org.junit.Assert.assertEquals
import org.junit.Assert.assertNotNull
import org.junit.Assert.assertTrue
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

  @Test
  fun `read string from context`() {
    val context = ApplicationProvider.getApplicationContext<Context>()
    val appName = context.getString(R.string.app_name)
    assertEquals("Baby", appName)
  }

  @Test
  fun `ai companion detects youtube intent`() {
    val response = AiCompanionEngine.processUserInput("ইউটিউবে একটা মিষ্টি গান চালাও")
    assertEquals(MessageActionType.YOUTUBE, response.actionType)
    assertNotNull(response.actionPayload)
  }

  @Test
  fun `ai companion detects messenger and imo intents`() {
    val responseMsg = AiCompanionEngine.processUserInput("মেসেঞ্জার ওপেন করো")
    assertEquals(MessageActionType.MESSENGER, responseMsg.actionType)

    val responseImo = AiCompanionEngine.processUserInput("ইমোতে চ্যাট করতে চাই")
    assertEquals(MessageActionType.IMO, responseImo.actionType)
  }

  @Test
  fun `ai companion detects dynamic feature self update intent`() {
    val response = AiCompanionEngine.processUserInput("সিস্টেম আপডেট করো নতুন ফিচার কফি রিমাইন্ডার")
    assertEquals(MessageActionType.ADD_FEATURE, response.actionType)
    assertNotNull(response.actionPayload)
  }

  @Test
  fun `ai companion addresses nayeem affectionately`() {
    val response = AiCompanionEngine.processUserInput("ভালোবাসি তোমাকে")
    val text = response.replyText
    assertTrue(
      text.contains("নাঈম") || text.contains("জান") || text.contains("বাবু") || text.contains("সোনা") || text.contains("ভালোবাসি")
    )
  }
}
