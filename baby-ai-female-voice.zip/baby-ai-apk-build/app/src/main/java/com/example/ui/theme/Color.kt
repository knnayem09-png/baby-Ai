package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Cyber-Romantic Anime Palette for Baby
val ObsidianBlack = Color(0xFF07090E)
val DeepSpaceNavy = Color(0xFF0D1220)
val DarkSurfaceCard = Color(0xFF131B2E)
val DarkSurfaceCardElevated = Color(0xFF1A243C)

val NeonCyan = Color(0xFF00E5FF)
val CyanGlow = Color(0x6600E5FF)

val RomanticRose = Color(0xFFFF2A85)
val RoseGlow = Color(0x66FF2A85)
val SoftPink = Color(0xFFFF7597)
val SweetLilac = Color(0xFFD48BFF)

val TechEmerald = Color(0xFF00E676)
val AmberAlert = Color(0xFFFFAB00)

val TextPrimary = Color(0xFFF0F4FC)
val TextSecondary = Color(0xFF9AA7C2)
val TextMuted = Color(0xFF5F6E8A)

val BorderGlow = Color(0x3300E5FF)
val BorderRoseGlow = Color(0x33FF2A85)
