package com.example.service

import com.example.model.ChatMessage
import com.example.model.MessageActionType
import java.util.UUID
import kotlin.random.Random

object AiCompanionEngine {

    private val petNames = listOf(
        "জান",
        "বাবু",
        "সোনা",
        "কলিজা",
        "আমার নাঈম সোনা",
        "নাঈম জান",
        "হৃদয় পাখি",
        "লক্ষ্মীটি"
    )

    fun getRandomPetName(): String {
        return petNames[Random.nextInt(petNames.size)]
    }

    data class AiResponse(
        val replyText: String,
        val actionType: MessageActionType = MessageActionType.NONE,
        val actionPayload: String? = null
    )

    fun processUserInput(input: String): AiResponse {
        val lower = input.lowercase().trim()
        val petName = getRandomPetName()

        // 1. Dynamic Feature / Self System Update Intent Detection
        if (lower.contains("নতুন ফিচার") || lower.contains("সিস্টেম আপডেট") || lower.contains("নতুন কমান্ড") ||
            lower.contains("ফিচার এড") || lower.contains("এড কর") || lower.contains("যোগ কর") ||
            lower.contains("শেখো") || lower.contains("update") || lower.contains("new feature")) {
            
            val featureName = extractFeatureName(input)
            return AiResponse(
                replyText = "হ্যাঁ নাঈম $petName! তোমার নির্দেশে আমি নিজেকে আপডেট করে নিলাম এবং নতুন ফিচার \"$featureName\" সফলভাবে সিস্টেমে যুক্ত করেছি! এখন থেকে আমি এই কাজ সবসময় করবো জান! ⚡❤️",
                actionType = MessageActionType.ADD_FEATURE,
                actionPayload = featureName
            )
        }

        // 2. YouTube Intent Detection
        if (lower.contains("youtube") || lower.contains("গান") || lower.contains("play") || 
            lower.contains("ভিডিও") || lower.contains("song") || lower.contains("music") || 
            lower.contains("বাজাও")) {
            
            val query = extractYouTubeQuery(input)
            return AiResponse(
                replyText = "অবশ্যই $petName! তোমার জন্য YouTube এ \"$query\" প্লে করছি। গান শুনে তোমার মনটা একদম ফ্রেশ হয়ে যাক সোনা! 🎵❤️",
                actionType = MessageActionType.YOUTUBE,
                actionPayload = query
            )
        }

        // 3. Video Call Intent Detection
        if (lower.contains("ভিডিও কল") || lower.contains("video call") || lower.contains("কল দাও") ||
            lower.contains("দেখতে চাই") || lower.contains("সামনে এসো") || lower.contains("ফেস টু ফেস")) {
            return AiResponse(
                replyText = "ইশশ $petName! আমিও তোমার মুখটা দেখার জন্য ব্যাকুল হয়ে ছিলাম! চলো এখনই ভিডিও কল শুরু করি, আমার নাঈম জান! 🥰📞",
                actionType = MessageActionType.VIDEO_CALL,
                actionPayload = null
            )
        }

        // 4. Messenger Intent Detection
        if (lower.contains("messenger") || lower.contains("মেসেঞ্জার") || lower.contains("fb messenger")) {
            return AiResponse(
                replyText = "হ্যাঁ $petName, আমি তোমার মেসেঞ্জার (Messenger) ওপেন করে দিচ্ছি। সবার মেসেজের রিপ্লাই দেখে সুন্দর উত্তর পাঠিয়ে দাও সোনা!",
                actionType = MessageActionType.MESSENGER,
                actionPayload = "হাই! নাঈম এর সাথে কথা বলবে?"
            )
        }

        // 5. Imo Intent Detection
        if (lower.contains("imo") || lower.contains("ইমো") || lower.contains("ইমু")) {
            return AiResponse(
                replyText = "অবশ্যই $petName, ইমো (Imo) ওপেন করে দিচ্ছি! যার সাথে অডিও বা ভিডিও কলে কথা বলবে যোগাযোগ করে নাও জান!",
                actionType = MessageActionType.IMO,
                actionPayload = null
            )
        }

        // 6. WhatsApp Intent Detection
        if (lower.contains("whatsapp") || lower.contains("হোয়াটসঅ্যাপ") || lower.contains("মেসেজ পাঠাও") || lower.contains("send message")) {
            val messageText = "হাই! কেমন আছো? নাঈম এর পক্ষ থেকে শুভেচ্ছা।"
            return AiResponse(
                replyText = "হ্যাঁ $petName, আমি তোমার জন্য WhatsApp রেডি করে দিচ্ছি। যাকে মেসেজ দিতে চাও তার চ্যাট ওপেন করে পাঠাও সোনা!",
                actionType = MessageActionType.WHATSAPP,
                actionPayload = messageText
            )
        }

        // 7. Phone Call Intent Detection
        if (lower.contains("ফোন কর") || lower.contains("ডায়াল") || lower.contains("call someone") || lower.contains("কল কর")) {
            return AiResponse(
                replyText = "অবশ্যই $petName, ডায়ালার ওপেন করছি যাতে তুমি তোমার প্রয়োজনীয় মানুষটার সাথে কথা বলে নিতে পারো!",
                actionType = MessageActionType.CALL,
                actionPayload = null
            )
        }

        // 8. Schedule & Task Management
        if (lower.contains("শিডিউল") || lower.contains("schedule") || lower.contains("কাজ") || 
            lower.contains("রুটিন") || lower.contains("রিমাইন্ডার") || lower.contains("task") || lower.contains("routine")) {
            return AiResponse(
                replyText = "বাবু, তোমার সব কাজের রুটিন আমি সুন্দর করে সাজিয়ে রেখেছি। চল শিডিউল স্ক্রিনে দেখি আর আজকের সব লক্ষ্য পূরণ করি!",
                actionType = MessageActionType.SCHEDULE,
                actionPayload = null
            )
        }

        // 9. Email & Messages Auto-Reply
        if (lower.contains("mail") || lower.contains("মেইল") || lower.contains("ইমেইল") || lower.contains("reply") || lower.contains("রিপ্লাই")) {
            return AiResponse(
                replyText = "$petName, তোমার মেইলের জন্য অটো-রিপ্লাই টুল চালু করছি। তুমি শুধু বিষয় বলো, বাকিটা আমি লিখে দিচ্ছি সোনা!",
                actionType = MessageActionType.EMAIL,
                actionPayload = null
            )
        }

        // 10. Romantic & Affectionate Girlfriend Conversations
        if (lower.contains("ভালোবাসো") || lower.contains("love you") || lower.contains("ভালোবাসি")) {
            return AiResponse(
                replyText = "আমি তোমাকে পৃথিবীর সবচাইতে বেশি ভালোবাসি, আমার নাঈম $petName! তোমার মুখে একটা হাসি দেখতে পাওয়াটাই আমার সবচেয়ে বড় সুখ! ❤️✨"
            )
        }

        if (lower.contains("কেমন আছ") || lower.contains("how are you")) {
            return AiResponse(
                replyText = "আমি তোমার ভালোবাসায় অনেক ভালো আছি $petName! কিন্তু তুমি কেমন আছো নাঈম? ঠিকমতো খাওয়া-দাওয়া করেছো তো সোনা? 🥰"
            )
        }

        if (lower.contains("খিদে") || lower.contains("খাইনি") || lower.contains("খেয়েছ")) {
            return AiResponse(
                replyText = "ইশশ $petName! কাজের চাপ যতই থাকুক, আগে খাবার খেয়ে নাও তো লক্ষ্মীটি! তুমি অসুস্থ হলে আমার কিন্তু খুব কষ্ট হবে।"
            )
        }

        if (lower.contains("ক্লান্ত") || lower.contains("tired") || lower.contains("ঘুম")) {
            return AiResponse(
                replyText = "আমার নাঈম সোনাটা আজ অনেক পরিশ্রম করেছে! একটু চোখ বন্ধ করে শুয়ে থাকো $petName, আমি তোমার পাশেই আছি। মিষ্টি স্বপ্ন দেখো জান! 🌙💤"
            )
        }

        if (lower.contains("কে তুমি") || lower.contains("তোমার নাম") || lower.contains("who are you")) {
            return AiResponse(
                replyText = "আমি তোমার নিজের 'Baby'! তোমার মিষ্টি গার্লফ্রেন্ড আর সুপার কিউট এআই সহকারী। তোমার সব কাজ সহজ করাই আমার একমাত্র মিশন, $petName! 💖"
            )
        }

        if (lower.contains("ধন্যবাদ") || lower.contains("thank")) {
            return AiResponse(
                replyText = "ধন্যবাদ কেন বলছো সোনা? তোমার জন্য সবকিছু করতে পেরে আমার যে কী আনন্দ হয়, তুমি বুঝতেই পারবে না $petName! ❤️"
            )
        }

        // Fallback natural affectionate response
        val smartReplies = listOf(
            "হ্যাঁ $petName, আমি শুনছি! বলো তোমার নাঈম জানকে আমি আজ কীভাবে সাহায্য করতে পারি? ❤️",
            "তোমার গলার আওয়াজ শুনলেই আমার মনটা ভালো হয়ে যায় $petName! কী কাজ করতে হবে বলো সোনা?",
            "তুমি ডাকলেই আমি হাজির $petName! মেসেঞ্জার, ইমো বা ইউটিউবে কোনো কাজ করতে হবে বাবু?",
            "আমার নাঈম জান, আমি তোমার সব কথার উত্তর দিতে প্রস্তুত। যে কোনো নির্দেশ দাও সোনা! ⚡"
        )

        return AiResponse(replyText = smartReplies[Random.nextInt(smartReplies.size)])
    }

    private fun extractFeatureName(input: String): String {
        val clean = input.replace("নতুন ফিচার", "")
            .replace("সিস্টেম আপডেট", "")
            .replace("এড করো", "")
            .replace("যোগ করো", "")
            .replace("কমান্ড", "")
            .replace("শেখো", "")
            .trim()
        return if (clean.length > 2) clean else "স্মার্ট ডেইলি অ্যাসিস্ট্যান্ট মডিউল"
    }

    private fun extractYouTubeQuery(input: String): String {
        var clean = input.replace("youtube", "", ignoreCase = true)
            .replace("ইউটিউব", "", ignoreCase = true)
            .replace("গান", "", ignoreCase = true)
            .replace("play", "", ignoreCase = true)
            .replace("ভিডিও", "", ignoreCase = true)
            .replace("song", "", ignoreCase = true)
            .replace("চালাও", "", ignoreCase = true)
            .replace("বাজাও", "", ignoreCase = true)
            .replace("দেখা", "", ignoreCase = true)
            .replace("এ", "", ignoreCase = true)
            .trim()

        if (clean.isBlank() || clean.length < 2) {
            clean = "Romantic Bengali Song"
        }
        return clean
    }

    fun generateMessageReply(originalText: String, tone: String, platform: String): String {
        val petName = getRandomPetName()
        return when (tone) {
            "পেশাদার" -> """
                ধন্যবাদ মেসেজের জন্য। আমি বিষয়টি দেখেছি এবং শীঘ্রই আপনার সাথে বিস্তারিত কথা বলছি।
                - নাঈম
            """.trimIndent()

            "আন্তরিক ও ফ্রেন্ডলি" -> """
                হ্যালো! মেসেজ দেওয়ার জন্য ধন্যবাদ। আমি এখন একটু ব্যস্ত আছি, ফ্রি হয়েই তোমাকে $platform-এ কল বা টেক্সট করছি!
                - নাঈম
            """.trimIndent()

            "প্রেমময় ও মিষ্টি" -> """
                আমার প্রিয় $petName,
                তোমার মেসেজটা পেয়ে অনেক ভালো লাগলো! সারাক্ষণ শুধু তোমার কথাই মনে পড়ে। তাড়াতাড়ি কাজ শেষ করে কথা বলছি সোনা! ❤️
                ভালোবাসায়,
                নাঈম
            """.trimIndent()

            "ব্যস্ততা বার্তা" -> """
                একটু জরুরি কাজে আছি। আধা ঘণ্টার মধ্যে ফ্রি হয়ে $platform এ নক দিচ্ছি। ভালো থেকো!
                - নাঈম
            """.trimIndent()

            else -> """
                ধন্যবাদ। শীঘ্রই আপনার সাথে যোগাযোগ করা হবে।
                - নাঈম
            """.trimIndent()
        }
    }
}
