package com.example.ui.components

import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.LinearEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.rotate
import androidx.compose.ui.draw.scale
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RomanticRose
import com.example.ui.theme.SoftPink
import com.example.ui.theme.SweetLilac

@Composable
fun AnimeCharacterDisplay(
    isSpeaking: Boolean,
    modifier: Modifier = Modifier,
    sizeDp: Dp = 260.dp,
    onClick: () -> Unit = {}
) {
    val infiniteTransition = rememberInfiniteTransition(label = "AnimeAnimation")

    // Breathing float animation
    val breathingOffset by infiniteTransition.animateFloat(
        initialValue = -5f,
        targetValue = 5f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isSpeaking) 600 else 1800, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "breathing"
    )

    // Gentle speaking tilt & scale animation
    val speakingScale by infiniteTransition.animateFloat(
        initialValue = 1f,
        targetValue = if (isSpeaking) 1.06f else 1.01f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isSpeaking) 450 else 2200, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "speakingScale"
    )

    val speakingTilt by infiniteTransition.animateFloat(
        initialValue = -1.5f,
        targetValue = 1.5f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isSpeaking) 500 else 3000, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "speakingTilt"
    )

    // Rotating anime magic halo ring
    val haloRotation by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = 360f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isSpeaking) 5000 else 14000, easing = LinearEasing)
        ),
        label = "haloRotation"
    )

    // Floating heart 1
    val heartFloat1 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -35f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "heartFloat1"
    )

    // Floating heart 2
    val heartFloat2 by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -45f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1800, delayMillis = 400, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "heartFloat2"
    )

    Box(
        modifier = modifier
            .size(sizeDp)
            .clickable(onClick = onClick)
            .testTag("anime_character_display"),
        contentAlignment = Alignment.Center
    ) {
        // Outer glowing halo (Anime magical aura)
        Box(
            modifier = Modifier
                .size(sizeDp - 10.dp)
                .rotate(haloRotation)
                .border(
                    width = if (isSpeaking) 3.dp else 1.5.dp,
                    brush = Brush.sweepGradient(
                        listOf(
                            SweetLilac,
                            RomanticRose,
                            Color.Transparent,
                            NeonCyan,
                            Color.Transparent,
                            SweetLilac
                        )
                    ),
                    shape = CircleShape
                )
        )

        // Pulsing background glow when talking
        if (isSpeaking) {
            Box(
                modifier = Modifier
                    .size(sizeDp - 30.dp)
                    .scale(speakingScale * 1.08f)
                    .clip(CircleShape)
                    .background(
                        Brush.radialGradient(
                            listOf(
                                RomanticRose.copy(alpha = 0.45f),
                                SweetLilac.copy(alpha = 0.25f),
                                Color.Transparent
                            )
                        )
                    )
            )
        }

        // Inner Anime Portrait Container
        Box(
            modifier = Modifier
                .size(sizeDp - 40.dp)
                .offset(y = breathingOffset.dp)
                .rotate(speakingTilt)
                .scale(speakingScale)
                .clip(CircleShape)
                .border(
                    width = 2.5.dp,
                    brush = Brush.linearGradient(
                        listOf(
                            if (isSpeaking) RomanticRose else SweetLilac,
                            if (isSpeaking) SweetLilac else NeonCyan
                        )
                    ),
                    shape = CircleShape
                )
                .shadow(
                    elevation = if (isSpeaking) 16.dp else 8.dp,
                    shape = CircleShape,
                    spotColor = RomanticRose
                )
                .background(DarkSurfaceCard),
            contentAlignment = Alignment.Center
        ) {
            Image(
                painter = painterResource(id = R.drawable.img_baby_avatar),
                contentDescription = "Baby Anime Girl Avatar",
                modifier = Modifier.fillMaxSize(),
                contentScale = ContentScale.Crop
            )
        }

        // Floating Animated Hearts & Stars when speaking
        if (isSpeaking) {
            Text(
                text = "❤️",
                fontSize = 18.sp,
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .offset(x = (-20).dp, y = (20 + heartFloat1).dp)
            )

            Text(
                text = "✨",
                fontSize = 16.sp,
                modifier = Modifier
                    .align(Alignment.TopStart)
                    .offset(x = 24.dp, y = (30 + heartFloat2).dp)
            )

            Text(
                text = "💜",
                fontSize = 15.sp,
                modifier = Modifier
                    .align(Alignment.BottomEnd)
                    .offset(x = (-30).dp, y = (-20 + heartFloat1).dp)
            )
        }

        // "Baby" Name Badge
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .offset(y = 10.dp)
                .clip(RoundedCornerShape(16.dp))
                .background(ObsidianBlack)
                .border(1.5.dp, RomanticRose, RoundedCornerShape(16.dp))
                .padding(horizontal = 14.dp, vertical = 4.dp)
        ) {
            Text(
                text = if (isSpeaking) "বেবি কথা বলছে... 🌸" else "বেবি (Baby) ❤️",
                fontSize = 12.sp,
                fontWeight = FontWeight.Bold,
                color = SoftPink
            )
        }
    }
}
