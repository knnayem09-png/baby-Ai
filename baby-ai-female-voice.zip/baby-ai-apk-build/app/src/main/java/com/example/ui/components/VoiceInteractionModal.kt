package com.example.ui.components

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.ModalBottomSheet
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.rememberModalBottomSheetState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceCardElevated
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RomanticRose
import com.example.ui.theme.SoftPink
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.BabyAssistantViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VoiceInteractionModal(
    viewModel: BabyAssistantViewModel,
    onDismiss: () -> Unit
) {
    val sheetState = rememberModalBottomSheetState(skipPartiallyExpanded = true)
    val isSpeaking by viewModel.isSpeaking.collectAsState()
    val lastSpeech by viewModel.ttsManager.lastSpokenText.collectAsState()
    var spokenInput by remember { mutableStateOf("") }

    ModalBottomSheet(
        onDismissRequest = onDismiss,
        sheetState = sheetState,
        containerColor = DarkSurfaceCardElevated,
        contentColor = TextPrimary
    ) {
        Column(
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 20.dp, vertical = 8.dp)
                .testTag("voice_interaction_modal"),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Top Close & Status Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "বেবির সাথে সরাসরি কথা বলুন ❤️",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = SoftPink
                )
                IconButton(onClick = onDismiss) {
                    Icon(imageVector = Icons.Default.Close, contentDescription = "Close", tint = TextSecondary)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Animated Anime Character in modal
            AnimeCharacterDisplay(
                isSpeaking = isSpeaking,
                sizeDp = 180.dp,
                onClick = {
                    val prompt = "নাঈম জান, আমি তোমার সব কথা মন দিয়ে শুনছি সোনা! বলো কি করবে?"
                    viewModel.ttsManager.speak(prompt)
                }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Audio Waveform
            VoiceWaveform(
                isSpeaking = isSpeaking,
                modifier = Modifier
                    .fillMaxWidth(0.8f)
                    .height(32.dp)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Subtitle banner showing what Baby said
            if (lastSpeech.isNotBlank()) {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, RomanticRose.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "বেবি: \"$lastSpeech\"",
                                color = TextPrimary,
                                fontSize = 13.sp,
                                lineHeight = 19.sp
                            )
                        }

                        IconButton(
                            onClick = { viewModel.ttsManager.speak(lastSpeech) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.VolumeUp,
                                contentDescription = "Replay",
                                tint = NeonCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }
                }
                Spacer(modifier = Modifier.height(10.dp))
            }

            // Quick Spoken Prompts Carousel
            Text(
                text = "মুখে বলুন বা ট্যাপ করে নির্দেশ দিন:",
                fontSize = 12.sp,
                color = TextSecondary,
                modifier = Modifier.align(Alignment.Start)
            )

            Spacer(modifier = Modifier.height(6.dp))

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickVoicePill("ইউটিউবে রোমান্টিক গান চালাও 🎵") {
                    viewModel.sendUserMessage("ইউটিউবে রোমান্টিক গান চালাও")
                }
                QuickVoicePill("কেমন আছো নাঈম এর জান? ❤️") {
                    viewModel.sendUserMessage("কেমন আছো জান?")
                }
                QuickVoicePill("আমাকে কতখানি ভালোবাসো? 💕") {
                    viewModel.sendUserMessage("আমাকে কতখানি ভালোবাসো সোনা?")
                }
                QuickVoicePill("আজকের কাজের শিডিউল কি? 📅") {
                    viewModel.sendUserMessage("আমার আজকের শিডিউল কি সোনা?")
                }
                QuickVoicePill("ভিডিও কল করো জান 📞") {
                    onDismiss()
                    viewModel.startVideoCall()
                }
                QuickVoicePill("মেসেঞ্জার ওপেন করো 💬") {
                    viewModel.launchMessenger("হাই!")
                }
                QuickVoicePill("ইমোতে চ্যাট করো 📞") {
                    viewModel.launchImo(null)
                }
                QuickVoicePill("নতুন ফিচার আপডেট করো ⚡") {
                    viewModel.sendUserMessage("সিস্টেম আপডেট করো নতুন ফিচার")
                }
                QuickVoicePill("আমার খুব ক্লান্তি লাগছে 🌙") {
                    viewModel.sendUserMessage("বাবু আমি অনেক ক্লান্ত")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Speech/Text input row
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(DarkSurfaceCard, RoundedCornerShape(24.dp))
                    .padding(horizontal = 8.dp, vertical = 4.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedTextField(
                    value = spokenInput,
                    onValueChange = { spokenInput = it },
                    placeholder = { Text("নাঈম জান, এখানে কিছু বলো...", fontSize = 13.sp, color = TextMuted) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = Color.Transparent,
                        unfocusedBorderColor = Color.Transparent,
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary
                    ),
                    modifier = Modifier.weight(1f)
                )

                IconButton(
                    onClick = {
                        if (spokenInput.isNotBlank()) {
                            viewModel.sendUserMessage(spokenInput)
                            spokenInput = ""
                        }
                    },
                    modifier = Modifier
                        .size(42.dp)
                        .clip(CircleShape)
                        .background(NeonCyan)
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.Send,
                        contentDescription = "Send",
                        tint = ObsidianBlack,
                        modifier = Modifier.size(18.dp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(20.dp))
        }
    }
}

@Composable
fun QuickVoicePill(
    text: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(DarkSurfaceCard)
            .border(1.dp, RomanticRose.copy(alpha = 0.4f), RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 12.dp, vertical = 7.dp)
    ) {
        Text(
            text = text,
            fontSize = 12.sp,
            color = TextPrimary,
            fontWeight = FontWeight.Medium
        )
    }
}
