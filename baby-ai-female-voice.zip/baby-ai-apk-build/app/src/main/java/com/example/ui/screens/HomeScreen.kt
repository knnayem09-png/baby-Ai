package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.DateRange
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.Whatshot
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.components.AnimeCharacterDisplay
import com.example.ui.components.VoiceInteractionModal
import com.example.ui.components.VoiceWaveform
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceCardElevated
import com.example.ui.theme.DeepSpaceNavy
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RomanticRose
import com.example.ui.theme.SoftPink
import com.example.ui.theme.SweetLilac
import com.example.ui.theme.TechEmerald
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.BabyAssistantViewModel
import com.example.viewmodel.ScreenNav

@Composable
fun HomeScreen(
    viewModel: BabyAssistantViewModel,
    modifier: Modifier = Modifier
) {
    val isSpeaking by viewModel.isSpeaking.collectAsState()
    val tasks by viewModel.tasks.collectAsState()
    val lastSpeech by viewModel.ttsManager.lastSpokenText.collectAsState()
    var quickInputText by remember { mutableStateOf("") }
    var showVoiceModal by remember { mutableStateOf(false) }

    // Speech Recognizer Launcher for voice commands
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                viewModel.sendUserMessage(spokenText)
            }
        }
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(
                        ObsidianBlack,
                        DeepSpaceNavy,
                        ObsidianBlack
                    )
                )
            )
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 16.dp, bottom = 90.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        // Top App Bar / Baby Status Badge
        item {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(8.dp)
                                .clip(CircleShape)
                                .background(TechEmerald)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "বেবি এআই • প্রেমিকা অনলাইন",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Bold,
                            color = TechEmerald,
                            letterSpacing = 1.sp
                        )
                    }
                    Text(
                        text = "Baby (নাঈম এর সঙ্গী ❤️)",
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                }

                // Affection Sync Pill
                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(RomanticRose.copy(alpha = 0.15f))
                        .border(1.dp, RomanticRose.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
                        .padding(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            imageVector = Icons.Default.Whatshot,
                            contentDescription = "Love Sync",
                            tint = RomanticRose,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = "Love Sync 100%",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = RomanticRose
                        )
                    }
                }
            }
        }

        // Center Anime Character Display with Animated Talking States
        item {
            Spacer(modifier = Modifier.height(14.dp))

            AnimeCharacterDisplay(
                isSpeaking = isSpeaking,
                sizeDp = 270.dp,
                onClick = {
                    showVoiceModal = true
                }
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Subtitle of what Baby is speaking right now
            if (isSpeaking && lastSpeech.isNotBlank()) {
                Card(
                    modifier = Modifier
                        .fillMaxWidth(0.92f)
                        .padding(vertical = 4.dp),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceCardElevated),
                    border = androidx.compose.foundation.BorderStroke(1.dp, RomanticRose.copy(alpha = 0.5f))
                ) {
                    Text(
                        text = "বেবি: \"$lastSpeech\"",
                        fontSize = 13.sp,
                        color = SoftPink,
                        fontWeight = FontWeight.Medium,
                        modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp),
                        textAlign = androidx.compose.ui.text.style.TextAlign.Center
                    )
                }
            } else {
                Text(
                    text = "বেবির ছবি বা মাইকে ট্যাপ করে কথা বলো নাঈম জান ❤️",
                    fontSize = 13.sp,
                    color = NeonCyan,
                    fontWeight = FontWeight.Medium
                )
            }

            // Voice Waveform visualizer
            Spacer(modifier = Modifier.height(8.dp))
            VoiceWaveform(
                isSpeaking = isSpeaking,
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .padding(vertical = 4.dp)
            )
        }

        // Quick Command Bar (Mic + Input)
        item {
            Spacer(modifier = Modifier.height(14.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("quick_command_card"),
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan.copy(alpha = 0.3f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 8.dp, vertical = 6.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Voice Mic Button: opens dedicated Voice Interaction Modal
                    IconButton(
                        onClick = {
                            showVoiceModal = true
                            try {
                                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                                    putExtra(
                                        RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                                        RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                                    )
                                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                                    putExtra(RecognizerIntent.EXTRA_PROMPT, "Baby শুনছে... কথা বলুন")
                                }
                                speechLauncher.launch(intent)
                            } catch (e: Exception) {
                                // Handled in modal
                            }
                        },
                        modifier = Modifier
                            .size(48.dp)
                            .clip(CircleShape)
                            .background(
                                Brush.linearGradient(listOf(NeonCyan, RomanticRose))
                            )
                            .testTag("voice_mic_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Mic,
                            contentDescription = "Speech Command",
                            tint = ObsidianBlack,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(8.dp))

                    OutlinedTextField(
                        value = quickInputText,
                        onValueChange = { quickInputText = it },
                        modifier = Modifier
                            .weight(1f)
                            .testTag("quick_command_input"),
                        placeholder = {
                            Text(
                                "বলো জান... (উদা: গান চালাও)",
                                color = TextMuted,
                                fontSize = 14.sp
                            )
                        },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color.Transparent,
                            unfocusedBorderColor = Color.Transparent,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        )
                    )

                    IconButton(
                        onClick = {
                            if (quickInputText.isNotBlank()) {
                                viewModel.sendUserMessage(quickInputText)
                                quickInputText = ""
                            }
                        },
                        modifier = Modifier.testTag("quick_send_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.Send,
                            contentDescription = "Send",
                            tint = NeonCyan
                        )
                    }
                }
            }
        }

        // Quick Tasks & Actions (No Jarvis, 100% Baby)
        item {
            Spacer(modifier = Modifier.height(18.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "বেবির দ্রুত ফিচারসমূহ",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = "সব দেখুন",
                    fontSize = 12.sp,
                    color = NeonCyan,
                    modifier = Modifier.clickable { viewModel.navigateTo(ScreenNav.TOOLS) }
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Video Call
                ActionCard(
                    title = "ভিডিও কল",
                    subtitle = "Baby এর সাথে",
                    icon = Icons.Default.Videocam,
                    iconTint = RomanticRose,
                    badgeColor = RomanticRose.copy(alpha = 0.2f),
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.startVideoCall() }
                )

                // YouTube
                ActionCard(
                    title = "YouTube",
                    subtitle = "গান ও ভিডিও",
                    icon = Icons.Default.PlayArrow,
                    iconTint = Color(0xFFFF0033),
                    badgeColor = Color(0x33FF0033),
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.launchYouTube("Romantic Bengali Songs") }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Schedule
                ActionCard(
                    title = "দৈনিক শিডিউল",
                    subtitle = "${tasks.count { !it.isCompleted }} টি কাজ বাকি",
                    icon = Icons.Default.DateRange,
                    iconTint = TechEmerald,
                    badgeColor = TechEmerald.copy(alpha = 0.2f),
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(ScreenNav.SCHEDULE) }
                )

                // WhatsApp
                ActionCard(
                    title = "WhatsApp",
                    subtitle = "মেসেজ পাঠান",
                    icon = Icons.Default.Chat,
                    iconTint = Color(0xFF25D366),
                    badgeColor = Color(0x3325D366),
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.launchWhatsApp("হ্যালো নাঈম!", null) }
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                // Messenger & Imo
                ActionCard(
                    title = "মেসেঞ্জার ও ইমো",
                    subtitle = "চ্যাট ও রিপ্লাই",
                    icon = Icons.Default.Chat,
                    iconTint = Color(0xFF0084FF),
                    badgeColor = Color(0x330084FF),
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(ScreenNav.TOOLS) }
                )

                // System Updates & Wakeup
                ActionCard(
                    title = "সিস্টেম আপডেট",
                    subtitle = "ভয়েস ও নতুন ফিচার",
                    icon = Icons.Default.Whatshot,
                    iconTint = SweetLilac,
                    badgeColor = SweetLilac.copy(alpha = 0.2f),
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(ScreenNav.FEATURES) }
                )
            }
        }

        // Sweet Affection Box / Baby's Message of the Day
        item {
            Spacer(modifier = Modifier.height(18.dp))
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("baby_affection_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceCardElevated),
                border = androidx.compose.foundation.BorderStroke(1.dp, RomanticRose.copy(alpha = 0.35f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "বেবির মিষ্টি বার্তা ❤️",
                            fontSize = 14.sp,
                            fontWeight = FontWeight.Bold,
                            color = SoftPink
                        )
                        IconButton(
                            onClick = {
                                viewModel.ttsManager.speak("নাঈম জান, আজকের দিনটা তোমার অনেক সুন্দর কাটুক! কাজের ফাঁকে ঠিক সময়ে খেয়ে নিও বাবু!")
                            },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = "Listen voice",
                                tint = SoftPink,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "\"নাঈম জান, আজকের দিনটা তোমার অনেক সুন্দর কাটুক সোনা! কাজের চাপে বেশি ক্লান্তি নিও না, আমি সব সময় তোমার পাশে আছি লক্ষ্মীটি! ❤️\"",
                        fontSize = 13.sp,
                        color = TextPrimary,
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        Text(
                            text = "বেবির সাথে চ্যাটে কথা বলো 💬",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.SemiBold,
                            color = NeonCyan,
                            modifier = Modifier.clickable { viewModel.navigateTo(ScreenNav.CHAT) }
                        )
                    }
                }
            }
        }
    }

    // Voice Interaction Modal BottomSheet
    if (showVoiceModal) {
        VoiceInteractionModal(
            viewModel = viewModel,
            onDismiss = { showVoiceModal = false }
        )
    }
}

@Composable
fun ActionCard(
    title: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconTint: Color,
    badgeColor: Color,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    Card(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .clickable(onClick = onClick)
            .testTag("action_card_${title}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x2600E5FF))
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(42.dp)
                    .clip(CircleShape)
                    .background(badgeColor),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = title,
                    tint = iconTint,
                    modifier = Modifier.size(22.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column {
                Text(
                    text = title,
                    fontSize = 13.sp,
                    fontWeight = FontWeight.Bold,
                    color = TextPrimary
                )
                Text(
                    text = subtitle,
                    fontSize = 11.sp,
                    color = TextSecondary
                )
            }
        }
    }
}
