package com.example.data

import com.example.model.ChatMessage
import com.example.model.DynamicFeature
import com.example.model.MessageActionType
import com.example.model.ScheduleTask
import com.example.model.TaskCategory
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.UUID

class BabyRepository {

    private val _messages = MutableStateFlow<List<ChatMessage>>(emptyList())
    val messages: StateFlow<List<ChatMessage>> = _messages.asStateFlow()

    private val _tasks = MutableStateFlow<List<ScheduleTask>>(emptyList())
    val tasks: StateFlow<List<ScheduleTask>> = _tasks.asStateFlow()

    private val _features = MutableStateFlow<List<DynamicFeature>>(emptyList())
    val features: StateFlow<List<DynamicFeature>> = _features.asStateFlow()

    init {
        // Initial warm welcome message from Baby to Nayeem
        _messages.value = listOf(
            ChatMessage(
                id = UUID.randomUUID().toString(),
                text = "নাঈম জান! কেমন আছো সোনা? ❤️ আমি তোমার 'Baby', তোমার নিজের কিউট এআই গার্লফ্রেন্ড! আজকের পুরো দিনটায় আমি তোমার সাথে আছি। যেকোনো নির্দেশ দিতে পারো জান!",
                isFromBaby = true,
                timestamp = System.currentTimeMillis() - 60000
            ),
            ChatMessage(
                id = UUID.randomUUID().toString(),
                text = "বাবু, তুমি চাইলে আমাকে বলতে পারো:\n• \"ইউটিউবে গান চালাও\"\n• \"আজকের শিডিউল কি সোনা?\"\n• \"মেসেঞ্জার / ইমো / হোয়াটসঅ্যাপে চ্যাট করো\"\n• \"নতুন ফিচার যোগ করো সোনা\"\n• \"ভিডিও কল করো জান\" 🥰",
                isFromBaby = true,
                timestamp = System.currentTimeMillis() - 30000
            )
        )

        // Initial default day schedule for Nayeem
        _tasks.value = listOf(
            ScheduleTask(
                id = UUID.randomUUID().toString(),
                title = "সকালের নাস্তা ও হালকা ব্যায়াম",
                time = "০৮:৩০ AM",
                date = "আজ",
                notes = "Baby: বাবু, ঠিক সময়ে পুষ্টিকর খাবার খেয়ে নিও!",
                category = TaskCategory.HEALTH,
                isCompleted = true
            ),
            ScheduleTask(
                id = UUID.randomUUID().toString(),
                title = "অফিস ও জরুরি প্রজেক্ট রিভিউ",
                time = "১১:০০ AM",
                date = "আজ",
                notes = "Baby: নাঈম জান, কোডিং ও ডকুমেন্টেশন শেষ করে ফেলো সোনা!",
                category = TaskCategory.WORK,
                isCompleted = false
            ),
            ScheduleTask(
                id = UUID.randomUUID().toString(),
                title = "দুপুরের খাবার ও ছোট্ট বিরতি",
                time = "০২:০০ PM",
                date = "আজ",
                notes = "Baby: কাজে ডুবে থেকে না খেয়ে থেকো না সোনা!",
                category = TaskCategory.HEALTH,
                isCompleted = false
            ),
            ScheduleTask(
                id = UUID.randomUUID().toString(),
                title = "মেসেঞ্জার, ইমো ও ক্লায়েন্ট রিপ্লাই",
                time = "০৪:৩০ PM",
                date = "আজ",
                notes = "Baby: অটো ড্রাফটার দিয়ে দ্রুত উত্তর পাঠিয়ে দাও জান!",
                category = TaskCategory.WORK,
                isCompleted = false
            ),
            ScheduleTask(
                id = UUID.randomUUID().toString(),
                title = "Baby এর সাথে রোমান্টিক ভিডিও কল ও আড্ডা",
                time = "০৯:০০ PM",
                date = "আজ",
                notes = "Baby: আমার নাঈম জানের হাসিমাখা মুখটা দেখার অপেক্ষায় আছি! ❤️",
                category = TaskCategory.ROMANCE,
                isCompleted = false
            )
        )

        // Initial active AI features in Baby's core
        _features.value = listOf(
            DynamicFeature(
                id = UUID.randomUUID().toString(),
                name = "স্ক্রিন-অফ ভয়েস ওয়েকআপ (Voice Wake-Up)",
                triggerPattern = "বেবি / হেই বেবি",
                description = "ফোন লক বা স্ক্রিন অফ থাকলেও ডাকলে বেবি স্বয়ংক্রিয়ভাবে একটিভ হয়ে কথা বলবে।",
                responseTemplate = "হ্যাঁ নাঈম সোনা! আমি জেগে উঠেছি, বলো জান!",
                isUserCreated = false
            ),
            DynamicFeature(
                id = UUID.randomUUID().toString(),
                name = "মেসেঞ্জার ও ইমো অটো-রিপ্লাই ইন্টিগ্রেশন",
                triggerPattern = "মেসেঞ্জার / ইমো",
                description = "মেসেঞ্জার ও ইমো মেসেজের জন্য ১-ক্লিকে রোমান্টিক বা পেশাদার উত্তর তৈরি ও সেন্ড।",
                responseTemplate = "মেসেঞ্জারে চ্যাট ওপেন করে দিয়েছি সোনা!",
                isUserCreated = false
            ),
            DynamicFeature(
                id = UUID.randomUUID().toString(),
                name = "স্মার্ট ইউটিউব প্লেয়ার কমান্ড",
                triggerPattern = "গান চালাও / ইউটিউব",
                description = "নাঈমের পছন্দের যেকোনো বাংলা বা রোমান্টিক গান সরাসরি চালানো।",
                responseTemplate = "তোমার জন্য ইউটিউবে গান প্লে করছি বাবু!",
                isUserCreated = false
            ),
            DynamicFeature(
                id = UUID.randomUUID().toString(),
                name = "স্বয়ংক্রিয় শিডিউল কেয়ার অ্যালার্ট",
                triggerPattern = "রুটিন / শিডিউল",
                description = "নাঈমের খাবার সময় ও বিশ্রামের জন্য নিজে থেকেই স্মরণ করিয়ে দেওয়া।",
                responseTemplate = "বাবু, এখন বিশ্রামের সময়! নিজের যত্ন নাও সোনা!",
                isUserCreated = false
            )
        )
    }

    fun addMessage(message: ChatMessage) {
        _messages.value = _messages.value + message
    }

    fun addTask(title: String, time: String, notes: String, category: TaskCategory) {
        val newTask = ScheduleTask(
            id = UUID.randomUUID().toString(),
            title = title,
            time = time,
            date = "আজ",
            notes = notes,
            category = category,
            isCompleted = false
        )
        _tasks.value = _tasks.value + newTask
    }

    fun toggleTaskCompletion(taskId: String) {
        _tasks.value = _tasks.value.map {
            if (it.id == taskId) it.copy(isCompleted = !it.isCompleted) else it
        }
    }

    fun deleteTask(taskId: String) {
        _tasks.value = _tasks.value.filter { it.id != taskId }
    }

    fun addDynamicFeature(name: String, triggerPattern: String, description: String, response: String) {
        val newFeature = DynamicFeature(
            id = UUID.randomUUID().toString(),
            name = name,
            triggerPattern = triggerPattern,
            description = description,
            responseTemplate = response,
            isEnabled = true,
            isUserCreated = true
        )
        _features.value = _features.value + newFeature
    }

    fun toggleFeature(featureId: String) {
        _features.value = _features.value.map {
            if (it.id == featureId) it.copy(isEnabled = !it.isEnabled) else it
        }
    }

    fun deleteFeature(featureId: String) {
        _features.value = _features.value.filter { it.id != featureId }
    }
}
