package com.example.service

import android.content.Context
import android.media.AudioAttributes
import android.media.AudioManager
import android.os.Bundle
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.speech.tts.Voice
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

class TtsManager(private val context: Context) : TextToSpeech.OnInitListener {

    private var tts: TextToSpeech? = null
    var isInitialized = false
        private set

    var isBengaliSupported = false
        private set

    private val _isSpeaking = MutableStateFlow(false)
    val isSpeaking: StateFlow<Boolean> = _isSpeaking.asStateFlow()

    private val _lastSpokenText = MutableStateFlow("")
    val lastSpokenText: StateFlow<String> = _lastSpokenText.asStateFlow()

    private val _currentPitch = MutableStateFlow(1.20f)
    val currentPitch: StateFlow<Float> = _currentPitch.asStateFlow()

    private val _currentRate = MutableStateFlow(0.88f)
    val currentRate: StateFlow<Float> = _currentRate.asStateFlow()

    init {
        tts = TextToSpeech(context.applicationContext, this)
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            val ttsEngine = tts ?: return

            // Prefer a Bengali voice first, then choose a feminine-sounding voice
            // for the selected language when the installed TTS engine exposes one.
            val bnLocale = Locale("bn", "BD")
            val bnCheck = ttsEngine.isLanguageAvailable(bnLocale)
            val selectedLocale = if (bnCheck >= TextToSpeech.LANG_AVAILABLE) {
                isBengaliSupported = true
                bnLocale
            } else {
                val bnInLocale = Locale("bn", "IN")
                val inCheck = ttsEngine.isLanguageAvailable(bnInLocale)
                if (inCheck >= TextToSpeech.LANG_AVAILABLE) {
                    isBengaliSupported = true
                    bnInLocale
                } else {
                    isBengaliSupported = false
                    Locale.US
                }
            }
            ttsEngine.language = selectedLocale

            try {
                val availableVoices = ttsEngine.voices.orEmpty()
                    .filter { it.locale.language == selectedLocale.language }
                    .filterNot { it.isNetworkConnectionRequired }
                val femaleHints = listOf("female", "fem", "woman", "girl", "sfg")
                val preferredVoice = availableVoices.firstOrNull { voice ->
                    val name = voice.name.lowercase(Locale.ROOT)
                    femaleHints.any { hint -> name.contains(hint) }
                } ?: availableVoices.maxByOrNull { voice ->
                    // Higher quality voices are usually smoother, when quality metadata is available.
                    voice.quality
                }
                if (preferredVoice != null) {
                    ttsEngine.voice = preferredVoice
                }
            } catch (e: Exception) {
                Log.w("TtsManager", "Could not set preferred voice: ${e.message}")
            }

            // A slightly brighter, gentle speaking style. Actual voice gender and accent
            // depend on voices installed on the user's Android TTS engine.
            _currentPitch.value = 1.28f
            _currentRate.value = 0.90f
            ttsEngine.setPitch(_currentPitch.value)
            ttsEngine.setSpeechRate(_currentRate.value)

            ttsEngine.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _isSpeaking.value = true
                }

                override fun onDone(utteranceId: String?) {
                    _isSpeaking.value = false
                }

                @Deprecated("Deprecated in Java")
                override fun onError(utteranceId: String?) {
                    _isSpeaking.value = false
                }

                override fun onError(utteranceId: String?, errorCode: Int) {
                    _isSpeaking.value = false
                }
            })

            isInitialized = true
        } else {
            Log.e("TtsManager", "TTS Initialization failed with status: $status")
        }
    }

    fun setVoiceSettings(pitch: Float, rate: Float) {
        _currentPitch.value = pitch.coerceIn(0.8f, 1.8f)
        _currentRate.value = rate.coerceIn(0.6f, 1.4f)
        tts?.setPitch(_currentPitch.value)
        tts?.setSpeechRate(_currentRate.value)
    }

    fun speak(text: String) {
        val cleanText = text.replace(Regex("[*#_~`•]"), "").trim()
        _lastSpokenText.value = cleanText

        if (!isInitialized) return

        val textToSpeak = if (isBengaliSupported) {
            cleanText
        } else {
            // Enhanced clear phonetics with proper syllable articulation
            transliterateBengaliToClearPhonetic(cleanText)
        }

        val utteranceId = "baby_voice_${System.currentTimeMillis()}"
        val params = Bundle().apply {
            putInt(TextToSpeech.Engine.KEY_PARAM_STREAM, AudioManager.STREAM_MUSIC)
            putFloat(TextToSpeech.Engine.KEY_PARAM_VOLUME, 1.0f)
        }

        tts?.speak(textToSpeak, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
    }

    fun stop() {
        tts?.stop()
        _isSpeaking.value = false
    }

    fun shutdown() {
        tts?.stop()
        tts?.shutdown()
        tts = null
        _isSpeaking.value = false
    }

    private fun transliterateBengaliToClearPhonetic(bengali: String): String {
        // High-clarity phonetic syllable mapping for crisp English TTS pronunciation
        var str = bengali
            .replace("নাঈম", "Naah-eem")
            .replace("নাইম", "Naah-eem")
            .replace("জান", "Jaahn")
            .replace("বাবু", "Baah-boo")
            .replace("সোনা", "Sho-nah")
            .replace("কলিজা", "Koh-lee-jah")
            .replace("লক্ষ্মীটি", "Lohk-khee-tee")
            .replace("কেমন আছো", "Kay-mon aah-chho")
            .replace("কেমন আছ", "Kay-mon aah-chho")
            .replace("ভালোবাসি", "Bhaah-loh-baah-shee")
            .replace("ভালোবাসো", "Bhaah-loh-baah-sho")
            .replace("ভালো আছি", "Bhaah-loh aah-chhee")
            .replace("ইউটিউবে", "YouTube-ay")
            .replace("গান", "Gaahn")
            .replace("বাজাচ্ছি", "baah-jahch-chhee")
            .replace("চালাচ্ছি", "chah-laahch-chhee")
            .replace("চালাও", "chah-laaho")
            .replace("ভিডিও", "Video")
            .replace("কল", "Call")
            .replace("শুরু করি", "shoo-roo koh-ree")
            .replace("মেসেঞ্জার", "Messenger")
            .replace("ইমো", "Imo")
            .replace("হোয়াটসঅ্যাপ", "WhatsApp")
            .replace("মেসেজ", "Message")
            .replace("পাঠাও", "paah-thaaho")
            .replace("পাঠিয়ে দাও", "paah-thee-yay daah-oh")
            .replace("শিডিউল", "Schedule")
            .replace("কাজ", "Kaaj")
            .replace("আজকের", "aahj-ker")
            .replace("খাবার", "khaah-baar")
            .replace("খেয়েছো", "khay-ay-chho")
            .replace("খেয়ে নাও", "khay-ay nah-oh")
            .replace("ক্লান্ত", "klaahn-toh")
            .replace("ঘুম", "ghoom")
            .replace("মিষ্টি", "meesh-tee")
            .replace("সুন্দর", "shoon-dohr")
            .replace("হৃদয় পাখি", "hree-doy paah-khee")
            .replace("অবশ্যই", "Oh-bosh-shoi")
            .replace("বলো", "boh-loh")
            .replace("শুনছি", "shoon-chhee")
            .replace("আমি", "Aah-mee")
            .replace("তোমার", "toh-maahr")
            .replace("তোমাকে", "toh-maah-kay")
            .replace("অনেক", "oh-nayk")
            .replace("পাশে আছি", "paah-shay aah-chhee")
            .replace("মনটা", "mohn-tah")
            .replace("আমার", "aah-maahr")
            .replace("তুমি", "too-mee")
            .replace("আপডেট", "Update")
            .replace("নতুন ফিচার", "New Feature")
            .replace("যুক্ত করেছি", "added koh-ray-chhee")
            .replace("সিস্টেম", "System")
            .replace("হ্যাঁ", "Hae")

        // If unknown Bengali words remain, articulate gracefully
        val bengaliCharsCount = str.count { it in '\u0980'..'\u09FF' }
        if (bengaliCharsCount > str.length / 3) {
            str = "Hae Naah-eem jaahn! Aah-mee shoon-chhee sho-nah! Aah-mee toh-maahr meesh-tee Baby!"
        }

        return str
    }
}
