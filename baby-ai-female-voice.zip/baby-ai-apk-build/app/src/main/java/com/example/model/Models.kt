package com.example.model

enum class TaskCategory {
    WORK,
    PERSONAL,
    ROMANCE,
    HEALTH,
    STUDY
}

data class ScheduleTask(
    val id: String,
    val title: String,
    val time: String,
    val date: String,
    val notes: String = "",
    val category: TaskCategory = TaskCategory.PERSONAL,
    val isCompleted: Boolean = false
)

enum class MessageActionType {
    NONE,
    YOUTUBE,
    WHATSAPP,
    MESSENGER,
    IMO,
    EMAIL,
    CALL,
    VIDEO_CALL,
    SCHEDULE,
    ADD_FEATURE
}

data class ChatMessage(
    val id: String,
    val text: String,
    val isFromBaby: Boolean,
    val timestamp: Long = System.currentTimeMillis(),
    val actionType: MessageActionType = MessageActionType.NONE,
    val actionPayload: String? = null
)

data class MailDraft(
    val recipient: String = "",
    val subject: String = "",
    val body: String = "",
    val tone: String = "পেশাদার",
    val platform: String = "Email" // Messenger / Imo / WhatsApp / Email
)

enum class BabyMood(val displayName: String, val emoji: String) {
    LOVING("প্রেমময়ী", "❤️"),
    CARING("যত্নশীল", "🥰"),
    SMART("স্মার্ট বেবি", "⚡"),
    SWEET("মিষ্টি বাবু", "✨"),
    PLAYFUL("খুশি", "🌸")
}

data class DynamicFeature(
    val id: String,
    val name: String,
    val triggerPattern: String,
    val description: String,
    val responseTemplate: String,
    val isEnabled: Boolean = true,
    val isUserCreated: Boolean = true,
    val createdAt: Long = System.currentTimeMillis()
)
