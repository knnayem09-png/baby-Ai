package com.example.ui.screens

import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.ContentCopy
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Forum
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material.icons.filled.VideoChat
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceCardElevated
import com.example.ui.theme.DeepSpaceNavy
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RomanticRose
import com.example.ui.theme.SoftPink
import com.example.ui.theme.TechEmerald
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.BabyAssistantViewModel
import com.example.viewmodel.ScreenNav

@Composable
fun ToolsScreen(
    viewModel: BabyAssistantViewModel,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val mailDraft by viewModel.mailDraft.collectAsState()

    var ytQuery by remember { mutableStateOf("Romantic Bengali Love Songs") }
    var selectedPlatform by remember { mutableStateOf("Messenger") }
    var incomingMessageText by remember { mutableStateOf("হাই নাঈম, কেমন আছো? কাজের কি খবর?") }
    var selectedTone by remember { mutableStateOf("প্রেমময় ও মিষ্টি") }

    var targetPhone by remember { mutableStateOf("") }
    var quickSendText by remember { mutableStateOf("হাই! কেমন আছো? নাঈম এর সাথে কথা বলবে?") }

    BackHandler {
        viewModel.navigateTo(ScreenNav.HOME)
    }

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(ObsidianBlack, DeepSpaceNavy, ObsidianBlack)
                )
            )
            .statusBarsPadding()
            .padding(horizontal = 16.dp),
        contentPadding = PaddingValues(top = 12.dp, bottom = 90.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Header
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                verticalAlignment = Alignment.CenterVertically
            ) {
                IconButton(
                    onClick = { viewModel.navigateTo(ScreenNav.HOME) },
                    modifier = Modifier.testTag("tools_back_button")
                ) {
                    Icon(
                        imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                        contentDescription = "Back",
                        tint = TextPrimary
                    )
                }
                Spacer(modifier = Modifier.width(6.dp))
                Column {
                    Text(
                        text = "বেবির স্মার্ট টুলস ও অটোমেশন ⚡",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "মেসেঞ্জার, ইমো, ইউটিউব ও অটো-রিপ্লাই",
                        fontSize = 12.sp,
                        color = NeonCyan
                    )
                }
            }
        }

        // Section 1: Quick App Launcher Bar (Messenger, Imo, WhatsApp, YouTube)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, NeonCyan.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "সরাসরি সোশ্যাল অ্যাপ লাঞ্চার:",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        // Messenger
                        SocialAppIcon(
                            name = "Messenger",
                            color = Color(0xFF0078FF),
                            icon = Icons.Default.Forum,
                            onClick = { viewModel.launchMessenger("হাই!") }
                        )

                        // Imo
                        SocialAppIcon(
                            name = "Imo",
                            color = Color(0xFF1E88E5),
                            icon = Icons.Default.VideoChat,
                            onClick = { viewModel.launchImo(null) }
                        )

                        // WhatsApp
                        SocialAppIcon(
                            name = "WhatsApp",
                            color = Color(0xFF25D366),
                            icon = Icons.Default.Chat,
                            onClick = { viewModel.launchWhatsApp("হাই!", null) }
                        )

                        // YouTube
                        SocialAppIcon(
                            name = "YouTube",
                            color = Color(0xFFFF0033),
                            icon = Icons.Default.PlayArrow,
                            onClick = { viewModel.launchYouTube("Romantic Bengali Songs") }
                        )
                    }
                }
            }
        }

        // Section 2: Universal AI Message & Reply Generator (Messenger, Imo, WhatsApp, Email)
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tool_email_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, RomanticRose.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(RomanticRose.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.AutoAwesome,
                                contentDescription = "Auto Reply",
                                tint = RomanticRose,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "মেসেঞ্জার ও ইমো অটো-রিপ্লাই 💬",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "বেবি যেকোনো মেসেজের স্মার্ট উত্তর তৈরি করে দেবে",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Platform selector
                    Text(text = "কোন প্ল্যাটফর্মে পাঠাবেন:", fontSize = 12.sp, color = TextSecondary)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("Messenger", "Imo", "WhatsApp", "Email").forEach { plat ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (selectedPlatform == plat) NeonCyan else DarkSurfaceCardElevated)
                                    .clickable { selectedPlatform = plat }
                                    .padding(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = plat,
                                    color = if (selectedPlatform == plat) ObsidianBlack else TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = if (selectedPlatform == plat) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    OutlinedTextField(
                        value = incomingMessageText,
                        onValueChange = { incomingMessageText = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("incoming_mail_input"),
                        label = { Text("মেসেঞ্জারে বা ইমোতে আসা মেসেজটি লিখুন", color = TextSecondary) },
                        maxLines = 3,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = RomanticRose,
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Tone selector
                    Text(text = "রিপ্লাইয়ের ধরন (Tone):", fontSize = 12.sp, color = TextSecondary)
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf("প্রেমময় ও মিষ্টি", "আন্তরিক ও ফ্রেন্ডলি", "ব্যস্ততা বার্তা", "পেশাদার").forEach { tone ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(if (selectedTone == tone) RomanticRose else DarkSurfaceCardElevated)
                                    .clickable { selectedTone = tone }
                                    .padding(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Text(
                                    text = tone,
                                    color = if (selectedTone == tone) Color.White else TextPrimary,
                                    fontSize = 11.sp,
                                    fontWeight = if (selectedTone == tone) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { viewModel.generateAutoReply(incomingMessageText, selectedTone, selectedPlatform) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("generate_reply_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = RomanticRose),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Text(text = "স্মার্ট রিপ্লাই তৈরি করুন ⚡", fontWeight = FontWeight.Bold, color = Color.White)
                    }

                    if (mailDraft.body.isNotBlank()) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            colors = CardDefaults.cardColors(containerColor = DarkSurfaceCardElevated),
                            border = androidx.compose.foundation.BorderStroke(1.dp, SoftPink.copy(alpha = 0.5f))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = "বেবির তৈরি করা রিপ্লাই ($selectedPlatform):",
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SoftPink
                                )
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = mailDraft.body,
                                    fontSize = 13.sp,
                                    color = TextPrimary,
                                    lineHeight = 18.sp
                                )

                                Spacer(modifier = Modifier.height(10.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.End,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    // Copy
                                    IconButton(
                                        onClick = {
                                            val clipboard = context.getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
                                            val clip = ClipData.newPlainText("Reply", mailDraft.body)
                                            clipboard.setPrimaryClip(clip)
                                            Toast.makeText(context, "রিপ্লাই কপি করা হয়েছে!", Toast.LENGTH_SHORT).show()
                                        }
                                    ) {
                                        Icon(
                                            imageVector = Icons.Default.ContentCopy,
                                            contentDescription = "Copy",
                                            tint = NeonCyan,
                                            modifier = Modifier.size(18.dp)
                                        )
                                    }

                                    Spacer(modifier = Modifier.width(6.dp))

                                    // Open target app
                                    Button(
                                        onClick = {
                                            when (selectedPlatform) {
                                                "Messenger" -> viewModel.launchMessenger(mailDraft.body)
                                                "Imo" -> viewModel.launchImo(null)
                                                "WhatsApp" -> viewModel.launchWhatsApp(mailDraft.body, null)
                                                else -> viewModel.launchEmail("", "মেসেজ রিপ্লাই", mailDraft.body)
                                            }
                                        },
                                        colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = ObsidianBlack),
                                        shape = RoundedCornerShape(10.dp),
                                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                                    ) {
                                        Icon(
                                            imageVector = Icons.AutoMirrored.Filled.Send,
                                            contentDescription = "Send",
                                            modifier = Modifier.size(14.dp)
                                        )
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text(text = "$selectedPlatform এ পাঠান", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // Section 3: YouTube Music & Video Player
        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("tool_youtube_card"),
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0x33FF0033))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(0x33FF0033)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.PlayArrow,
                                contentDescription = "YouTube",
                                tint = Color(0xFFFF0033),
                                modifier = Modifier.size(22.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "YouTube প্লেয়ার ও গান",
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "Baby তোমার পছন্দের গান ও ভিডিও চালিয়ে দেবে",
                                fontSize = 11.sp,
                                color = TextSecondary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    OutlinedTextField(
                        value = ytQuery,
                        onValueChange = { ytQuery = it },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("yt_query_input"),
                        label = { Text("গান বা ভিডিওর নাম লিখুন", color = TextSecondary) },
                        singleLine = true,
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedBorderColor = Color(0xFFFF0033),
                            focusedTextColor = TextPrimary,
                            unfocusedTextColor = TextPrimary
                        ),
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Quick Genre Pills
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .horizontalScroll(rememberScrollState()),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf(
                            "রোমান্টিক গান",
                            "Lo-Fi Chill Beats",
                            "অরিজিৎ সিং স্পেশাল",
                            "বাংলা নাটক",
                            "কোরআন তেলাওয়াত"
                        ).forEach { tag ->
                            Box(
                                modifier = Modifier
                                    .clip(RoundedCornerShape(10.dp))
                                    .background(DarkSurfaceCardElevated)
                                    .border(1.dp, Color(0x22FF0033), RoundedCornerShape(10.dp))
                                    .clickable { ytQuery = tag }
                                    .padding(horizontal = 8.dp, vertical = 4.dp)
                            ) {
                                Text(text = tag, color = TextPrimary, fontSize = 11.sp)
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Button(
                        onClick = { viewModel.launchYouTube(ytQuery) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("yt_play_button"),
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFFF0033)),
                        shape = RoundedCornerShape(12.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.PlayArrow,
                            contentDescription = "Play",
                            modifier = Modifier.size(18.dp)
                        )
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "YouTube এ এখনই চালান",
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun SocialAppIcon(
    name: String,
    color: Color,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    onClick: () -> Unit
) {
    Column(
        horizontalAlignment = Alignment.CenterHorizontally,
        modifier = Modifier
            .clickable(onClick = onClick)
            .padding(6.dp)
    ) {
        Box(
            modifier = Modifier
                .size(46.dp)
                .clip(CircleShape)
                .background(color.copy(alpha = 0.2f))
                .border(1.5.dp, color, CircleShape),
            contentAlignment = Alignment.Center
        ) {
            Icon(
                imageVector = icon,
                contentDescription = name,
                tint = color,
                modifier = Modifier.size(24.dp)
            )
        }
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = name,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = TextPrimary
        )
    }
}
