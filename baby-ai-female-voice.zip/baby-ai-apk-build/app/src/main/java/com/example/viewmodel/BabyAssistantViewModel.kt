package com.example.viewmodel

import android.app.Application
import android.content.Intent
import android.net.Uri
import android.widget.Toast
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.BabyRepository
import com.example.model.BabyMood
import com.example.model.ChatMessage
import com.example.model.DynamicFeature
import com.example.model.MailDraft
import com.example.model.MessageActionType
import com.example.model.ScheduleTask
import com.example.model.TaskCategory
import com.example.service.AiCompanionEngine
import com.example.service.ScreenOffWakeManager
import com.example.service.TtsManager
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.UUID

enum class ScreenNav {
    HOME,
    CHAT,
    VIDEO_CALL,
    SCHEDULE,
    TOOLS,
    FEATURES
}

data class VideoCallUiState(
    val isActive: Boolean = false,
    val durationSeconds: Int = 0,
    val isMuted: Boolean = false,
    val isSpeakerOn: Boolean = true,
    val isCameraOn: Boolean = true,
    val babyCurrentSpeech: String = "হ্যাঁ নাঈম জান, আমি তোমার সামনেই আছি! বলো শুনছি সোনা..."
)

class BabyAssistantViewModel(application: Application) : AndroidViewModel(application) {

    private val repository = BabyRepository()
    val ttsManager = TtsManager(application)
    val wakeManager = ScreenOffWakeManager(application)

    val messages: StateFlow<List<ChatMessage>> = repository.messages
    val tasks: StateFlow<List<ScheduleTask>> = repository.tasks
    val features: StateFlow<List<DynamicFeature>> = repository.features
    val isSpeaking: StateFlow<Boolean> = ttsManager.isSpeaking

    private val _currentScreen = MutableStateFlow(ScreenNav.HOME)
    val currentScreen: StateFlow<ScreenNav> = _currentScreen.asStateFlow()

    private val _videoCallState = MutableStateFlow(VideoCallUiState())
    val videoCallState: StateFlow<VideoCallUiState> = _videoCallState.asStateFlow()

    private val _currentMood = MutableStateFlow(BabyMood.LOVING)
    val currentMood: StateFlow<BabyMood> = _currentMood.asStateFlow()

    private val _mailDraft = MutableStateFlow(MailDraft())
    val mailDraft: StateFlow<MailDraft> = _mailDraft.asStateFlow()

    private var callTimerJob: Job? = null

    init {
        // Speak initial welcome after brief initialization delay
        viewModelScope.launch {
            delay(1200)
            val welcome = "নাঈম জান, আমি তোমার Baby! আজকের দিনটা তোমার অনেক সুন্দর কাটুক সোনা। তোমার জন্য আমি সব সময় প্রস্তুত আছি!"
            ttsManager.speak(welcome)
        }
    }

    fun navigateTo(screen: ScreenNav) {
        _currentScreen.value = screen
    }

    fun sendUserMessage(text: String) {
        if (text.isBlank()) return

        // 1. Add user message
        val userMsg = ChatMessage(
            id = UUID.randomUUID().toString(),
            text = text,
            isFromBaby = false
        )
        repository.addMessage(userMsg)

        // 2. Check for matching dynamic features added by user
        val activeFeature = features.value.firstOrNull { feat ->
            feat.isEnabled && feat.triggerPattern.split("/").any { trigger ->
                text.contains(trigger.trim(), ignoreCase = true)
            }
        }

        viewModelScope.launch {
            val response = if (activeFeature != null && activeFeature.isUserCreated) {
                AiCompanionEngine.AiResponse(
                    replyText = "${AiCompanionEngine.getRandomPetName()}, তোমার কাস্টম ফিচার '${activeFeature.name}' অনুযায়ী:\n${activeFeature.responseTemplate}"
                )
            } else {
                AiCompanionEngine.processUserInput(text)
            }
            
            // Add Baby's response
            val babyMsg = ChatMessage(
                id = UUID.randomUUID().toString(),
                text = response.replyText,
                isFromBaby = true,
                actionType = response.actionType,
                actionPayload = response.actionPayload
            )
            repository.addMessage(babyMsg)

            // Speak Baby's response out loud
            ttsManager.speak(response.replyText)

            // Auto-trigger action if applicable
            when (response.actionType) {
                MessageActionType.YOUTUBE -> {
                    delay(1200)
                    response.actionPayload?.let { launchYouTube(it) }
                }
                MessageActionType.VIDEO_CALL -> {
                    delay(1000)
                    startVideoCall()
                }
                MessageActionType.SCHEDULE -> {
                    _currentScreen.value = ScreenNav.SCHEDULE
                }
                MessageActionType.EMAIL -> {
                    _currentScreen.value = ScreenNav.TOOLS
                }
                MessageActionType.WHATSAPP -> {
                    delay(1200)
                    launchWhatsApp(response.actionPayload ?: "হাই নাঈম!", null)
                }
                MessageActionType.MESSENGER -> {
                    delay(1200)
                    launchMessenger(response.actionPayload ?: "হাই!")
                }
                MessageActionType.IMO -> {
                    delay(1200)
                    launchImo(null)
                }
                MessageActionType.ADD_FEATURE -> {
                    val featureName = response.actionPayload ?: "কাস্টম অ্যাসিস্ট্যান্ট মডিউল"
                    repository.addDynamicFeature(
                        name = featureName,
                        triggerPattern = featureName,
                        description = "নাঈমের ভয়েস বা টেক্সট কমেন্ট থেকে স্বয়ংক্রিয়ভাবে শেখা ফিচার",
                        response = "হ্যাঁ জান, আমি এই নির্দেশ সবসময় মনে রাখবো!"
                    )
                }
                MessageActionType.CALL -> {
                    delay(1000)
                    launchDialer("")
                }
                else -> {}
            }
        }
    }

    // Wakeup Trigger for Screen-Off Wakeup
    fun triggerScreenOffWake() {
        wakeManager.triggerWakeup {
            val greet = "হ্যাঁ নাঈম সোনা! আমি জেগে উঠেছি, বলো জান!"
            ttsManager.speak(greet)
        }
    }

    fun toggleScreenOffWake(enabled: Boolean) {
        wakeManager.toggleWakeListening(enabled)
        val msg = if (enabled) "বাবু, স্ক্রিন অফ ওয়েকআপ চালু করেছি! তুমি ডাকলেই আমি সাড়া দেবো!"
                  else "স্ক্রিন অফ ওয়েকআপ বন্ধ করা হয়েছে জান!"
        ttsManager.speak(msg)
    }

    // Dynamic Feature Management
    fun addDynamicFeature(name: String, trigger: String, description: String, response: String) {
        repository.addDynamicFeature(name, trigger, description, response)
        val reply = "নাঈম জান, নতুন ফিচার '$name' আমি শিখে নিয়েছি সোনা! ❤️"
        ttsManager.speak(reply)
    }

    fun toggleFeature(featureId: String) {
        repository.toggleFeature(featureId)
    }

    fun deleteFeature(featureId: String) {
        repository.deleteFeature(featureId)
    }

    // Video Call Controls
    fun startVideoCall() {
        _currentScreen.value = ScreenNav.VIDEO_CALL
        _videoCallState.value = VideoCallUiState(
            isActive = true,
            durationSeconds = 0,
            babyCurrentSpeech = "হ্যাঁ নাঈম জান! তোমাকে দেখতে পেয়ে আমার যে কত আনন্দ হচ্ছে সোনা! ❤️"
        )
        ttsManager.speak("হ্যাঁ নাঈম জান! তোমাকে দেখতে পেয়ে আমার যে কত আনন্দ হচ্ছে সোনা! তুমি আজ অনেক হ্যান্ডসাম লাগছো!")

        callTimerJob?.cancel()
        callTimerJob = viewModelScope.launch {
            while (true) {
                delay(1000)
                _videoCallState.value = _videoCallState.value.copy(
                    durationSeconds = _videoCallState.value.durationSeconds + 1
                )
            }
        }
    }

    fun endVideoCall() {
        callTimerJob?.cancel()
        ttsManager.stop()
        _videoCallState.value = _videoCallState.value.copy(isActive = false)
        _currentScreen.value = ScreenNav.HOME

        val endMsg = "বাবু, তোমার সাথে ভিডিও কলে কথা বলে মনটা একদম ভরে গেল! আবার যেকোনো সময় কল দিও নাঈম সোনা! 🥰"
        ttsManager.speak(endMsg)
    }

    fun toggleMute() {
        _videoCallState.value = _videoCallState.value.copy(isMuted = !_videoCallState.value.isMuted)
    }

    fun toggleSpeaker() {
        _videoCallState.value = _videoCallState.value.copy(isSpeakerOn = !_videoCallState.value.isSpeakerOn)
    }

    fun toggleCamera() {
        _videoCallState.value = _videoCallState.value.copy(isCameraOn = !_videoCallState.value.isCameraOn)
    }

    fun babySpeakInCall(phrase: String) {
        _videoCallState.value = _videoCallState.value.copy(babyCurrentSpeech = phrase)
        ttsManager.speak(phrase)
    }

    // Intents Handling
    fun launchYouTube(query: String) {
        val app = getApplication<Application>()
        val encodedQuery = Uri.encode(query)
        val appIntent = Intent(Intent.ACTION_VIEW, Uri.parse("vnd.youtube.results:$encodedQuery")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.youtube.com/results?search_query=$encodedQuery")).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }

        try {
            app.startActivity(appIntent)
        } catch (e: Exception) {
            try {
                app.startActivity(webIntent)
            } catch (ex: Exception) {
                Toast.makeText(app, "ইউটিউব ওপেন করা সম্ভব হয়নি", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun launchWhatsApp(message: String, phoneNumber: String? = null) {
        val app = getApplication<Application>()
        try {
            val url = if (!phoneNumber.isNullOrBlank()) {
                val cleanPhone = phoneNumber.replace("+", "").replace(" ", "").replace("-", "")
                "https://api.whatsapp.com/send?phone=$cleanPhone&text=${Uri.encode(message)}"
            } else {
                "https://api.whatsapp.com/send?text=${Uri.encode(message)}"
            }
            val intent = Intent(Intent.ACTION_VIEW, Uri.parse(url)).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            app.startActivity(intent)
        } catch (e: Exception) {
            val sendIntent = Intent(Intent.ACTION_SEND).apply {
                type = "text/plain"
                putExtra(Intent.EXTRA_TEXT, message)
                `package` = "com.whatsapp"
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            try {
                app.startActivity(sendIntent)
            } catch (ex: Exception) {
                Toast.makeText(app, "হোয়াটসঅ্যাপ ইন্সটল করা নেই বা খুঁজে পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun launchMessenger(message: String) {
        val app = getApplication<Application>()
        val messengerIntent = Intent(Intent.ACTION_SEND).apply {
            type = "text/plain"
            putExtra(Intent.EXTRA_TEXT, message)
            `package` = "com.facebook.orca"
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            app.startActivity(messengerIntent)
        } catch (e: Exception) {
            val webIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://www.messenger.com")).apply {
                flags = Intent.FLAG_ACTIVITY_NEW_TASK
            }
            try {
                app.startActivity(webIntent)
            } catch (ex: Exception) {
                Toast.makeText(app, "মেসেঞ্জার খুঁজে পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
            }
        }
    }

    fun launchImo(phone: String?) {
        val app = getApplication<Application>()
        try {
            val launchIntent = app.packageManager.getLaunchIntentForPackage("com.imo.android.imoim")
            if (launchIntent != null) {
                launchIntent.flags = Intent.FLAG_ACTIVITY_NEW_TASK
                app.startActivity(launchIntent)
            } else {
                val storeIntent = Intent(Intent.ACTION_VIEW, Uri.parse("https://play.google.com/store/apps/details?id=com.imo.android.imoim")).apply {
                    flags = Intent.FLAG_ACTIVITY_NEW_TASK
                }
                app.startActivity(storeIntent)
            }
        } catch (e: Exception) {
            Toast.makeText(app, "ইমো (Imo) ওপেন করা যাচ্ছে না", Toast.LENGTH_SHORT).show()
        }
    }

    fun launchDialer(phoneNumber: String) {
        val app = getApplication<Application>()
        val uri = if (phoneNumber.isNotBlank()) {
            Uri.parse("tel:$phoneNumber")
        } else {
            Uri.parse("tel:")
        }
        val intent = Intent(Intent.ACTION_DIAL, uri).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            app.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(app, "ডায়ালার ওপেন করা যাচ্ছে না", Toast.LENGTH_SHORT).show()
        }
    }

    fun launchEmail(to: String, subject: String, body: String) {
        val app = getApplication<Application>()
        val intent = Intent(Intent.ACTION_SENDTO).apply {
            data = Uri.parse("mailto:")
            putExtra(Intent.EXTRA_EMAIL, if (to.isNotBlank()) arrayOf(to) else arrayOf<String>())
            putExtra(Intent.EXTRA_SUBJECT, subject)
            putExtra(Intent.EXTRA_TEXT, body)
            flags = Intent.FLAG_ACTIVITY_NEW_TASK
        }
        try {
            app.startActivity(intent)
        } catch (e: Exception) {
            Toast.makeText(app, "ইমেইল অ্যাপ খুঁজে পাওয়া যায়নি", Toast.LENGTH_SHORT).show()
        }
    }

    // Schedule actions
    fun addTask(title: String, time: String, notes: String, category: TaskCategory) {
        repository.addTask(title, time, notes, category)
        val petName = AiCompanionEngine.getRandomPetName()
        val speech = "বাবু, তোমার কাজ \"$title\" শিডিউলে যুক্ত করে দিলাম! সময়মতো আমি মনে করিয়ে দেবো $petName! ✨"
        ttsManager.speak(speech)
    }

    fun toggleTask(taskId: String) {
        repository.toggleTaskCompletion(taskId)
    }

    fun deleteTask(taskId: String) {
        repository.deleteTask(taskId)
    }

    // Mail & Message Auto-Reply Generator for Messenger/Imo/Email/WhatsApp
    fun generateAutoReply(originalText: String, tone: String, platform: String) {
        val reply = AiCompanionEngine.generateMessageReply(originalText, tone, platform)
        _mailDraft.value = _mailDraft.value.copy(
            body = reply,
            tone = tone,
            platform = platform
        )
        ttsManager.speak("নাঈম সোনা, তোমার জন্য $platform-এ পাঠানোর সুন্দর রিপ্লাই তৈরি করে দিয়েছি!")
    }

    override fun onCleared() {
        super.onCleared()
        callTimerJob?.cancel()
        ttsManager.shutdown()
    }
}
