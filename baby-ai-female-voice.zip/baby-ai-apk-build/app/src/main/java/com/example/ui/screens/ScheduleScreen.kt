package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.RadioButtonUnchecked
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ScheduleTask
import com.example.model.TaskCategory
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceCardElevated
import com.example.ui.theme.DeepSpaceNavy
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RomanticRose
import com.example.ui.theme.SoftPink
import com.example.ui.theme.TechEmerald
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.BabyAssistantViewModel
import com.example.viewmodel.ScreenNav

@Composable
fun ScheduleScreen(
    viewModel: BabyAssistantViewModel,
    modifier: Modifier = Modifier
) {
    val tasks by viewModel.tasks.collectAsState()
    var selectedCategory by remember { mutableStateOf<TaskCategory?>(null) }
    var showAddDialog by remember { mutableStateOf(false) }

    BackHandler {
        viewModel.navigateTo(ScreenNav.HOME)
    }

    val filteredTasks = remember(tasks, selectedCategory) {
        if (selectedCategory == null) tasks else tasks.filter { it.category == selectedCategory }
    }

    val remainingCount = tasks.count { !it.isCompleted }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(ObsidianBlack, DeepSpaceNavy, ObsidianBlack)
                )
            )
            .statusBarsPadding()
            .testTag("schedule_screen")
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp)
        ) {
            // Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        IconButton(
                            onClick = { viewModel.navigateTo(ScreenNav.HOME) },
                            modifier = Modifier.testTag("schedule_back_button")
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                                contentDescription = "Back",
                                tint = TextPrimary
                            )
                        }
                        Spacer(modifier = Modifier.width(4.dp))
                        Column {
                            Text(
                                text = "নাঈম এর দৈনিক শিডিউল 📅",
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = TextPrimary
                            )
                            Text(
                                text = "আজকের $remainingCount টি কাজ বাকি আছে",
                                fontSize = 12.sp,
                                color = if (remainingCount > 0) NeonCyan else TechEmerald
                            )
                        }
                    }

                    // Voice Summary button
                    IconButton(
                        onClick = {
                            val msg = "নাঈম জান, তোমার আজকের মোট ${tasks.size}টি কাজের মধ্যে $remainingCount টি বাকি আছে। মন দিয়ে কাজগুলো শেষ করে নাও সোনা, আমি তোমার পাশেই আছি!"
                            viewModel.ttsManager.speak(msg)
                        },
                        modifier = Modifier
                            .clip(CircleShape)
                            .background(RomanticRose.copy(alpha = 0.2f))
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                            contentDescription = "Voice Summary",
                            tint = SoftPink
                        )
                    }
                }
            }

            // Baby's Advice Card
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceCardElevated),
                    border = androidx.compose.foundation.BorderStroke(1.dp, RomanticRose.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "Baby এর কাজের পরামর্শ 💡",
                            fontSize = 13.sp,
                            fontWeight = FontWeight.Bold,
                            color = SoftPink
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (remainingCount > 0)
                                "\"বাবু, কাজ জমে থাকলে ভয় পাবে না। একে একে সব শেষ করে ফেলো জান। কাজের পর আমি কিন্তু ভিডিও কল করবো সোনা! ❤️\""
                            else
                                "\"দারুণ বাবু! আজকের সব কাজ তুমি শেষ করে ফেলেছো! তুমি আসলেই সেরা আমার নাঈম সোনা! 🥰\"",
                            fontSize = 12.sp,
                            color = TextPrimary,
                            lineHeight = 18.sp
                        )
                    }
                }
            }

            // Category Filter Row
            item {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    CategoryFilterChip(
                        label = "সব (${tasks.size})",
                        isSelected = selectedCategory == null,
                        onClick = { selectedCategory = null }
                    )
                    CategoryFilterChip(
                        label = "অফিস ও কাজ",
                        isSelected = selectedCategory == TaskCategory.WORK,
                        onClick = { selectedCategory = TaskCategory.WORK }
                    )
                    CategoryFilterChip(
                        label = "রোমান্টিক ও Baby",
                        isSelected = selectedCategory == TaskCategory.ROMANCE,
                        onClick = { selectedCategory = TaskCategory.ROMANCE }
                    )
                    CategoryFilterChip(
                        label = "স্বাস্থ্য ও খাবার",
                        isSelected = selectedCategory == TaskCategory.HEALTH,
                        onClick = { selectedCategory = TaskCategory.HEALTH }
                    )
                    CategoryFilterChip(
                        label = "ব্যক্তিগত",
                        isSelected = selectedCategory == TaskCategory.PERSONAL,
                        onClick = { selectedCategory = TaskCategory.PERSONAL }
                    )
                }
            }

            // Tasks List
            items(filteredTasks, key = { it.id }) { task ->
                TaskItemCard(
                    task = task,
                    onToggle = { viewModel.toggleTask(task.id) },
                    onDelete = { viewModel.deleteTask(task.id) }
                )
            }
        }

        // Floating Action Button to Add New Task
        FloatingActionButton(
            onClick = { showAddDialog = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp)
                .testTag("add_task_fab"),
            containerColor = NeonCyan,
            contentColor = ObsidianBlack
        ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = "Add Task")
        }

        // Add Task Dialog
        if (showAddDialog) {
            AddTaskDialog(
                onDismiss = { showAddDialog = false },
                onAdd = { title, time, notes, cat ->
                    viewModel.addTask(title, time, notes, cat)
                    showAddDialog = false
                }
            )
        }
    }
}

@Composable
fun TaskItemCard(
    task: ScheduleTask,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("task_card_${task.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (task.isCompleted) DarkSurfaceCard.copy(alpha = 0.5f) else DarkSurfaceCard
        ),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (task.isCompleted) Color(0x3300E676) else Color(0x2600E5FF)
        )
    ) {
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(14.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            IconButton(
                onClick = onToggle,
                modifier = Modifier.size(36.dp)
            ) {
                Icon(
                    imageVector = if (task.isCompleted) Icons.Default.CheckCircle else Icons.Default.RadioButtonUnchecked,
                    contentDescription = "Toggle Complete",
                    tint = if (task.isCompleted) TechEmerald else TextMuted,
                    modifier = Modifier.size(24.dp)
                )
            }

            Spacer(modifier = Modifier.width(10.dp))

            Column(modifier = Modifier.weight(1f)) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text(
                        text = task.time,
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Bold,
                        color = NeonCyan
                    )
                    Text(
                        text = "• ${getCategoryLabel(task.category)}",
                        fontSize = 11.sp,
                        color = TextSecondary
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))

                Text(
                    text = task.title,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.SemiBold,
                    color = if (task.isCompleted) TextMuted else TextPrimary,
                    textDecoration = if (task.isCompleted) TextDecoration.LineThrough else TextDecoration.None
                )

                if (task.notes.isNotBlank()) {
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = task.notes,
                        fontSize = 12.sp,
                        color = if (task.category == TaskCategory.ROMANCE) SoftPink else TextSecondary
                    )
                }
            }

            IconButton(
                onClick = onDelete,
                modifier = Modifier.size(32.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Delete,
                    contentDescription = "Delete",
                    tint = TextMuted.copy(alpha = 0.7f),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
    }
}

@Composable
fun CategoryFilterChip(
    label: String,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(16.dp))
            .background(if (isSelected) NeonCyan else DarkSurfaceCard)
            .border(
                1.dp,
                if (isSelected) NeonCyan else Color(0x3300E5FF),
                RoundedCornerShape(16.dp)
            )
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            text = label,
            fontSize = 12.sp,
            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
            color = if (isSelected) ObsidianBlack else TextPrimary
        )
    }
}

private fun getCategoryLabel(category: TaskCategory): String {
    return when (category) {
        TaskCategory.WORK -> "অফিস"
        TaskCategory.ROMANCE -> "Baby & রোমান্স"
        TaskCategory.HEALTH -> "স্বাস্থ্য"
        TaskCategory.PERSONAL -> "ব্যক্তিগত"
        TaskCategory.STUDY -> "পড়াশোনা"
    }
}

@Composable
fun AddTaskDialog(
    onDismiss: () -> Unit,
    onAdd: (title: String, time: String, notes: String, category: TaskCategory) -> Unit
) {
    var title by remember { mutableStateOf("") }
    var time by remember { mutableStateOf("০৫:০০ PM") }
    var notes by remember { mutableStateOf("") }
    var category by remember { mutableStateOf(TaskCategory.PERSONAL) }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurfaceCardElevated,
        title = {
            Text(
                text = "নতুন কাজের শিডিউল যোগ করুন",
                color = TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("কাজের নাম (উদা: মিটিং সম্পন্ন করা)", color = TextSecondary) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan
                    ),
                    modifier = Modifier.fillMaxWidth().testTag("add_task_title_input")
                )

                OutlinedTextField(
                    value = time,
                    onValueChange = { time = it },
                    label = { Text("সময় (উদা: ০৬:০০ PM)", color = TextSecondary) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("নোট বা Baby এর স্মরণ করিয়ে দেয়া বার্তা", color = TextSecondary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                // Category selector
                Text("ক্যাটাগরি:", color = TextSecondary, fontSize = 12.sp)
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .horizontalScroll(rememberScrollState()),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    TaskCategory.values().forEach { cat ->
                        Box(
                            modifier = Modifier
                                .clip(RoundedCornerShape(12.dp))
                                .background(if (category == cat) RomanticRose else DarkSurfaceCard)
                                .clickable { category = cat }
                                .padding(horizontal = 10.dp, vertical = 6.dp)
                        ) {
                            Text(
                                text = getCategoryLabel(cat),
                                color = if (category == cat) Color.White else TextSecondary,
                                fontSize = 11.sp
                            )
                        }
                    }
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (title.isNotBlank()) {
                        onAdd(title, time, notes, category)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = ObsidianBlack),
                modifier = Modifier.testTag("confirm_add_task_button")
            ) {
                Text("যুক্ত করুন", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল", color = TextSecondary)
            }
        }
    )
}
