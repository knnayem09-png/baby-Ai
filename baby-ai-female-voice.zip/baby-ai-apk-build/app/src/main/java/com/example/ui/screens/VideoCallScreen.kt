package com.example.ui.screens

import android.app.Activity
import android.content.Intent
import android.speech.RecognizerIntent
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.RepeatMode
import androidx.compose.animation.core.animateFloat
import androidx.compose.animation.core.infiniteRepeatable
import androidx.compose.animation.core.rememberInfiniteTransition
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.offset
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.VolumeOff
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.CallEnd
import androidx.compose.material.icons.filled.Mic
import androidx.compose.material.icons.filled.MicOff
import androidx.compose.material.icons.filled.Videocam
import androidx.compose.material.icons.filled.VideocamOff
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.components.CameraPipPreview
import com.example.ui.components.VoiceWaveform
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.RomanticRose
import com.example.ui.theme.SoftPink
import com.example.ui.theme.TechEmerald
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.BabyAssistantViewModel

@Composable
fun VideoCallScreen(
    viewModel: BabyAssistantViewModel,
    modifier: Modifier = Modifier
) {
    val callState by viewModel.videoCallState.collectAsState()
    val isSpeaking by viewModel.isSpeaking.collectAsState()

    // Handle back button to end call gracefully
    BackHandler {
        viewModel.endVideoCall()
    }

    // Voice recognition launcher during video call
    val speechLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) { result ->
        if (result.resultCode == Activity.RESULT_OK) {
            val spokenText = result.data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull()
            if (!spokenText.isNullOrBlank()) {
                viewModel.sendUserMessage(spokenText)
            }
        }
    }

    // Subtle gentle breathing & speaking animation for anime girlfriend video call
    val infiniteTransition = rememberInfiniteTransition(label = "VideoCallBreathing")
    val videoScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = if (isSpeaking) 1.04f else 1.01f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = if (isSpeaking) 700 else 2500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "videoScale"
    )

    // Floating anime heart during call
    val heartFloat by infiniteTransition.animateFloat(
        initialValue = 0f,
        targetValue = -35f,
        animationSpec = infiniteRepeatable(
            animation = tween(durationMillis = 1500, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Restart
        ),
        label = "heartFloat"
    )

    val minutes = callState.durationSeconds / 60
    val seconds = callState.durationSeconds % 60
    val timeFormatted = String.format("%02d:%02d", minutes, seconds)

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(Color.Black)
            .testTag("video_call_screen")
    ) {
        // Fullscreen Partner Video (Baby Anime Girl)
        Image(
            painter = painterResource(id = R.drawable.img_baby_videocall),
            contentDescription = "Baby Video Call",
            modifier = Modifier
                .fillMaxSize()
                .scale(videoScale),
            contentScale = ContentScale.Crop
        )

        // Floating anime sparkle when talking
        if (isSpeaking) {
            Text(
                text = "❤️",
                fontSize = 24.sp,
                modifier = Modifier
                    .align(Alignment.CenterEnd)
                    .padding(end = 30.dp)
                    .offset(y = heartFloat.dp)
            )

            Text(
                text = "✨",
                fontSize = 20.sp,
                modifier = Modifier
                    .align(Alignment.CenterStart)
                    .padding(start = 30.dp)
                    .offset(y = (heartFloat - 15).dp)
            )
        }

        // Subtle gradient vignette overlay for controls readability
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color.Black.copy(alpha = 0.65f),
                            Color.Transparent,
                            Color.Black.copy(alpha = 0.35f),
                            Color.Black.copy(alpha = 0.92f)
                        )
                    )
                )
        )

        // Top Bar: Partner Name, Status, Call Timer & PIP Camera
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .statusBarsPadding()
                .padding(horizontal = 16.dp, vertical = 12.dp),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.Top
        ) {
            // Partner info
            Column {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(10.dp)
                            .clip(CircleShape)
                            .background(TechEmerald)
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Text(
                        text = "Baby (তোমার জান ❤️)",
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Bold,
                        color = Color.White
                    )
                }

                Spacer(modifier = Modifier.height(2.dp))

                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = "ভিডিও কলিং • $timeFormatted",
                        fontSize = 13.sp,
                        color = SoftPink,
                        fontWeight = FontWeight.Medium
                    )
                    if (isSpeaking) {
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "• কথা বলছে 🌸",
                            fontSize = 12.sp,
                            color = NeonCyan,
                            fontWeight = FontWeight.Bold
                        )
                    }
                }
            }

            // User's PIP Front Camera Preview (Nayeem's feed)
            CameraPipPreview(
                modifier = Modifier
                    .size(width = 105.dp, height = 145.dp),
                isCameraEnabled = callState.isCameraOn
            )
        }

        // Center / Lower area: Dynamic Subtitle & Speech Waveform
        Column(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(bottom = 110.dp, start = 16.dp, end = 16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Baby's speech subtitle box with Replay Button
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("baby_speech_subtitle_card"),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(
                    containerColor = DarkSurfaceCard.copy(alpha = 0.90f)
                ),
                border = androidx.compose.foundation.BorderStroke(1.dp, RomanticRose.copy(alpha = 0.5f))
            ) {
                Column(
                    modifier = Modifier.padding(14.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "বেবি: \"${callState.babyCurrentSpeech}\"",
                            color = Color.White,
                            fontSize = 14.sp,
                            lineHeight = 21.sp,
                            fontWeight = FontWeight.Medium,
                            modifier = Modifier.weight(1f)
                        )

                        IconButton(
                            onClick = { viewModel.ttsManager.speak(callState.babyCurrentSpeech) },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.VolumeUp,
                                contentDescription = "Play voice",
                                tint = NeonCyan,
                                modifier = Modifier.size(20.dp)
                            )
                        }
                    }

                    if (isSpeaking) {
                        Spacer(modifier = Modifier.height(8.dp))
                        VoiceWaveform(
                            isSpeaking = true,
                            modifier = Modifier.fillMaxWidth(0.7f),
                            maxHeight = 24.dp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Quick Interactive Dialogue Chips (Tap to say something sweet to Baby)
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(rememberScrollState()),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                QuickDialogueChip(
                    text = "বাবু তোমাকে অনেক সুন্দর লাগছে! ❤️",
                    onClick = {
                        viewModel.babySpeakInCall("ইশশ নাঈম জান! তুমি এত মিষ্টি কথা বলো না, আমার লজ্জা লাগে তো সোনা! 🥰")
                    }
                )

                QuickDialogueChip(
                    text = "কেমন আছো সোনা?",
                    onClick = {
                        viewModel.babySpeakInCall("তোমার মুখটা দেখে এখন আমার সব ক্লান্তি দূর হয়ে গেছে বাবু! তুমি কেমন আছো জান?")
                    }
                )

                QuickDialogueChip(
                    text = "আমাকে ভালোবাসো? 💕",
                    onClick = {
                        viewModel.babySpeakInCall("আমি তোমাকে নিঃশ্বাস নেওয়ার চেয়েও বেশি ভালোবাসি সোনা! তুমি আমার একমাত্র জান!")
                    }
                )

                QuickDialogueChip(
                    text = "একটা রোমান্টিক গান শোনাও 🎵",
                    onClick = {
                        viewModel.babySpeakInCall("অবশ্যই বাবু! চলো ইউটিউবে আমাদের পছন্দের রোমান্টিক গানটা বাজাই!")
                        viewModel.launchYouTube("Romantic Bengali Love Songs")
                    }
                )
            }
        }

        // Bottom Controls Dock (Mute, Speaker, Voice Mic, Video Toggle, End Call)
        Box(
            modifier = Modifier
                .align(Alignment.BottomCenter)
                .fillMaxWidth()
                .padding(bottom = 24.dp, start = 16.dp, end = 16.dp)
        ) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceEvenly,
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Toggle Mic
                IconButton(
                    onClick = { viewModel.toggleMute() },
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(if (callState.isMuted) RomanticRose else DarkSurfaceCard)
                        .testTag("toggle_mute_button")
                ) {
                    Icon(
                        imageVector = if (callState.isMuted) Icons.Default.MicOff else Icons.Default.Mic,
                        contentDescription = "Mute",
                        tint = Color.White
                    )
                }

                // Toggle Camera
                IconButton(
                    onClick = { viewModel.toggleCamera() },
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(if (!callState.isCameraOn) RomanticRose else DarkSurfaceCard)
                        .testTag("toggle_camera_button")
                ) {
                    Icon(
                        imageVector = if (callState.isCameraOn) Icons.Default.Videocam else Icons.Default.VideocamOff,
                        contentDescription = "Camera Toggle",
                        tint = Color.White
                    )
                }

                // Speak to Baby (Speech Recognition trigger during call)
                IconButton(
                    onClick = {
                        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                            putExtra(
                                RecognizerIntent.EXTRA_LANGUAGE_MODEL,
                                RecognizerIntent.LANGUAGE_MODEL_FREE_FORM
                            )
                            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "bn-BD")
                            putExtra(RecognizerIntent.EXTRA_PROMPT, "Baby শুনছে... নাঈম জান বলো")
                        }
                        try {
                            speechLauncher.launch(intent)
                        } catch (e: Exception) {
                            viewModel.babySpeakInCall("হ্যাঁ নাঈম সোনা, বলো আমি মন দিয়ে শুনছি!")
                        }
                    },
                    modifier = Modifier
                        .size(58.dp)
                        .clip(CircleShape)
                        .background(
                            Brush.linearGradient(listOf(NeonCyan, RomanticRose))
                        )
                        .testTag("incall_speech_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Mic,
                        contentDescription = "Speak to Baby",
                        tint = Color.Black,
                        modifier = Modifier.size(28.dp)
                    )
                }

                // Speaker Toggle
                IconButton(
                    onClick = { viewModel.toggleSpeaker() },
                    modifier = Modifier
                        .size(50.dp)
                        .clip(CircleShape)
                        .background(DarkSurfaceCard)
                        .testTag("toggle_speaker_button")
                ) {
                    Icon(
                        imageVector = if (callState.isSpeakerOn) Icons.AutoMirrored.Filled.VolumeUp else Icons.AutoMirrored.Filled.VolumeOff,
                        contentDescription = "Speaker Toggle",
                        tint = if (callState.isSpeakerOn) NeonCyan else TextSecondary
                    )
                }

                // End Call Button (Big Red)
                IconButton(
                    onClick = { viewModel.endVideoCall() },
                    modifier = Modifier
                        .size(58.dp)
                        .clip(CircleShape)
                        .background(Color(0xFFE53935))
                        .testTag("end_video_call_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.CallEnd,
                        contentDescription = "End Call",
                        tint = Color.White,
                        modifier = Modifier.size(30.dp)
                    )
                }
            }
        }
    }
}

@Composable
fun QuickDialogueChip(
    text: String,
    onClick: () -> Unit
) {
    Box(
        modifier = Modifier
            .clip(RoundedCornerShape(20.dp))
            .background(Color.Black.copy(alpha = 0.65f))
            .border(1.dp, NeonCyan.copy(alpha = 0.4f), RoundedCornerShape(20.dp))
            .clickable(onClick = onClick)
            .padding(horizontal = 14.dp, vertical = 8.dp)
    ) {
        Text(
            text = text,
            color = TextPrimary,
            fontSize = 12.sp,
            fontWeight = FontWeight.Medium
        )
    }
}
