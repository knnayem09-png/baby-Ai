package com.example.ui.screens

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.AutoAwesome
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.GraphicEq
import androidx.compose.material.icons.filled.NotificationsActive
import androidx.compose.material.icons.filled.PowerSettingsNew
import androidx.compose.material.icons.filled.SettingsVoice
import androidx.compose.material.icons.filled.Speed
import androidx.compose.material3.AlertDialog
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableFloatStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.DynamicFeature
import com.example.ui.theme.DarkSurfaceCard
import com.example.ui.theme.DarkSurfaceCardElevated
import com.example.ui.theme.DeepSpaceNavy
import com.example.ui.theme.NeonCyan
import com.example.ui.theme.ObsidianBlack
import com.example.ui.theme.RomanticRose
import com.example.ui.theme.SoftPink
import com.example.ui.theme.TechEmerald
import com.example.ui.theme.TextMuted
import com.example.ui.theme.TextPrimary
import com.example.ui.theme.TextSecondary
import com.example.viewmodel.BabyAssistantViewModel
import com.example.viewmodel.ScreenNav

@Composable
fun FeaturesScreen(
    viewModel: BabyAssistantViewModel,
    modifier: Modifier = Modifier
) {
    val features by viewModel.features.collectAsState()
    val isWakeEnabled by viewModel.wakeManager.isWakeListeningEnabled.collectAsState()
    val currentPitch by viewModel.ttsManager.currentPitch.collectAsState()
    val currentRate by viewModel.ttsManager.currentRate.collectAsState()

    var showAddFeatureDialog by remember { mutableStateOf(false) }
    var pitchSlider by remember { mutableFloatStateOf(currentPitch) }
    var rateSlider by remember { mutableFloatStateOf(currentRate) }

    BackHandler {
        viewModel.navigateTo(ScreenNav.HOME)
    }

    Box(
        modifier = modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = listOf(ObsidianBlack, DeepSpaceNavy, ObsidianBlack)
                )
            )
            .statusBarsPadding()
            .testTag("features_screen")
    ) {
        LazyColumn(
            modifier = Modifier.fillMaxSize(),
            contentPadding = PaddingValues(start = 16.dp, end = 16.dp, top = 12.dp, bottom = 96.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            // Header
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(
                        onClick = { viewModel.navigateTo(ScreenNav.HOME) },
                        modifier = Modifier.testTag("features_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back",
                            tint = TextPrimary
                        )
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Column {
                        Text(
                            text = "সিস্টেম আপডেট ও নতুন ফিচার হাব ⚡",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = TextPrimary
                        )
                        Text(
                            text = "স্বয়ংক্রিয় শিখন, ভয়েস স্পষ্টতা ও ওয়েকআপ",
                            fontSize = 12.sp,
                            color = NeonCyan
                        )
                    }
                }
            }

            // Card 1: Screen-Off Voice Wakeup Control
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("wake_lock_card"),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, TechEmerald.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(36.dp)
                                        .clip(CircleShape)
                                        .background(TechEmerald.copy(alpha = 0.2f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.NotificationsActive,
                                        contentDescription = "Wake Lock",
                                        tint = TechEmerald,
                                        modifier = Modifier.size(20.dp)
                                    )
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        text = "স্ক্রিন-অফ ভয়েস ওয়েকআপ",
                                        fontSize = 15.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = TextPrimary
                                    )
                                    Text(
                                        text = if (isWakeEnabled) "সক্রিয়: ডাকলে স্ক্রিন অন হয়ে যাবে" else "নিষ্ক্রিয়",
                                        fontSize = 11.sp,
                                        color = if (isWakeEnabled) TechEmerald else TextMuted
                                    )
                                }
                            }

                            Switch(
                                checked = isWakeEnabled,
                                onCheckedChange = { viewModel.toggleScreenOffWake(it) },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = ObsidianBlack,
                                    checkedTrackColor = TechEmerald
                                )
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "ফোন স্ক্রিন অফ থাকলেও বা লক থাকলে মুখে \"বেবি\" বা \"হেই বেবি\" ডাকলে ফোন লাইট জ্বলে উঠবে এবং বেবি মিষ্টি কণ্ঠে জবাব দেবে!",
                            fontSize = 12.sp,
                            color = TextSecondary,
                            lineHeight = 17.sp
                        )

                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = { viewModel.triggerScreenOffWake() },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = TechEmerald, contentColor = ObsidianBlack),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.Default.PowerSettingsNew, contentDescription = "Test Wake", modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ওয়েকআপ টেস্ট করুন (Screen Wakeup)", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }

            // Card 2: Voice Clarity & Tone Tuning (স্পষ্ট বাংলা ও সুর নিয়ন্ত্রণ)
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .testTag("voice_clarity_card"),
                    shape = RoundedCornerShape(18.dp),
                    colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
                    border = androidx.compose.foundation.BorderStroke(1.dp, RomanticRose.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(RomanticRose.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.GraphicEq,
                                    contentDescription = "Voice Tuning",
                                    tint = RomanticRose,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "বেবির ভয়েস স্পষ্টতা ও সুর টিউনিং 🌸",
                                    fontSize = 15.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = TextPrimary
                                )
                                Text(
                                    text = "উচ্চারণ স্পষ্ট করতে পিচ ও গতি নিয়ন্ত্রণ করুন",
                                    fontSize = 11.sp,
                                    color = TextSecondary
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Pitch Slider
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("ভয়েস পিচ (মিষ্টি সুর):", fontSize = 12.sp, color = TextSecondary)
                            Text(String.format("%.2f", pitchSlider), fontSize = 12.sp, color = SoftPink, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = pitchSlider,
                            onValueChange = {
                                pitchSlider = it
                                viewModel.ttsManager.setVoiceSettings(pitchSlider, rateSlider)
                            },
                            valueRange = 0.9f..1.6f,
                            colors = SliderDefaults.colors(thumbColor = RomanticRose, activeTrackColor = RomanticRose)
                        )

                        // Speech Rate Slider
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("কথা বলার গতি (স্পষ্টতা বাড়াতে কম রাখুন):", fontSize = 12.sp, color = TextSecondary)
                            Text(String.format("%.2f", rateSlider), fontSize = 12.sp, color = NeonCyan, fontWeight = FontWeight.Bold)
                        }
                        Slider(
                            value = rateSlider,
                            onValueChange = {
                                rateSlider = it
                                viewModel.ttsManager.setVoiceSettings(pitchSlider, rateSlider)
                            },
                            valueRange = 0.6f..1.2f,
                            colors = SliderDefaults.colors(thumbColor = NeonCyan, activeTrackColor = NeonCyan)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = {
                                viewModel.ttsManager.speak("নাঈম জান, আমি তোমার মিষ্টি বেবি! এখন আমার কণ্ঠ একদম স্পষ্ট শোনা যাচ্ছে তো সোনা?")
                            },
                            modifier = Modifier.fillMaxWidth(),
                            colors = ButtonDefaults.buttonColors(containerColor = RomanticRose),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(imageVector = Icons.AutoMirrored.Filled.VolumeUp, contentDescription = "Test Voice", modifier = Modifier.size(16.dp), tint = Color.White)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("ভয়েসের স্পষ্টতা শুনুন 🔊", color = Color.White, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                        }
                    }
                }
            }

            // Card 3: Dynamic Self-Evolving Features & Custom Commands
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text(
                        text = "সক্রিয় এআই মডিউল (${features.size}টি)",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = TextPrimary
                    )
                    Text(
                        text = "+ নতুন কমান্ড শেখান",
                        fontSize = 12.sp,
                        color = NeonCyan,
                        fontWeight = FontWeight.SemiBold,
                        modifier = Modifier.clickable { showAddFeatureDialog = true }
                    )
                }
            }

            items(features, key = { it.id }) { feat ->
                FeatureCardItem(
                    feature = feat,
                    onToggle = { viewModel.toggleFeature(feat.id) },
                    onDelete = { viewModel.deleteFeature(feat.id) }
                )
            }
        }

        // Add Feature FAB
        FloatingActionButton(
            onClick = { showAddFeatureDialog = true },
            modifier = Modifier
                .align(Alignment.BottomEnd)
                .padding(20.dp),
            containerColor = NeonCyan,
            contentColor = ObsidianBlack
        ) {
            Icon(imageVector = Icons.Default.Add, contentDescription = "Add Feature")
        }

        // Add Feature Dialog
        if (showAddFeatureDialog) {
            AddDynamicFeatureDialog(
                onDismiss = { showAddFeatureDialog = false },
                onAdd = { name, trigger, desc, resp ->
                    viewModel.addDynamicFeature(name, trigger, desc, resp)
                    showAddFeatureDialog = false
                }
            )
        }
    }
}

@Composable
fun FeatureCardItem(
    feature: DynamicFeature,
    onToggle: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .testTag("feature_card_${feature.id}"),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = DarkSurfaceCard),
        border = androidx.compose.foundation.BorderStroke(
            1.dp,
            if (feature.isEnabled) NeonCyan.copy(alpha = 0.35f) else Color(0x22FFFFFF)
        )
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(28.dp)
                            .clip(CircleShape)
                            .background(if (feature.isEnabled) NeonCyan.copy(alpha = 0.2f) else DarkSurfaceCardElevated),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.AutoAwesome,
                            contentDescription = "Feature",
                            tint = if (feature.isEnabled) NeonCyan else TextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = feature.name,
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = if (feature.isEnabled) TextPrimary else TextMuted
                    )
                }

                Switch(
                    checked = feature.isEnabled,
                    onCheckedChange = { onToggle() },
                    colors = SwitchDefaults.colors(
                        checkedThumbColor = ObsidianBlack,
                        checkedTrackColor = NeonCyan
                    )
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = feature.description,
                fontSize = 12.sp,
                color = TextSecondary,
                lineHeight = 17.sp
            )

            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "ট্রিগার: \"${feature.triggerPattern}\"",
                    fontSize = 11.sp,
                    color = SoftPink,
                    fontWeight = FontWeight.Medium
                )

                if (feature.isUserCreated) {
                    IconButton(
                        onClick = onDelete,
                        modifier = Modifier.size(28.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Delete,
                            contentDescription = "Delete",
                            tint = TextMuted,
                            modifier = Modifier.size(16.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AddDynamicFeatureDialog(
    onDismiss: () -> Unit,
    onAdd: (name: String, trigger: String, description: String, response: String) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var trigger by remember { mutableStateOf("") }
    var desc by remember { mutableStateOf("") }
    var response by remember { mutableStateOf("") }

    AlertDialog(
        onDismissRequest = onDismiss,
        containerColor = DarkSurfaceCardElevated,
        title = {
            Text(
                text = "বেবিকে নতুন ফিচার বা কমান্ড শেখান ⚡",
                color = TextPrimary,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold
            )
        },
        text = {
            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                OutlinedTextField(
                    value = name,
                    onValueChange = { name = it },
                    label = { Text("ফিচারের নাম (উদা: কফি খাওয়ার রিমাইন্ডার)", color = TextSecondary) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = trigger,
                    onValueChange = { trigger = it },
                    label = { Text("কী বললে একটিভ হবে? (উদা: কফি / চা)", color = TextSecondary) },
                    singleLine = true,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan
                    ),
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = response,
                    onValueChange = { response = it },
                    label = { Text("বেবি কী উত্তর দেবে? (উদা: গরম কফি খেয়ে নাও জান!)", color = TextSecondary) },
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedTextColor = TextPrimary,
                        unfocusedTextColor = TextPrimary,
                        focusedBorderColor = NeonCyan
                    ),
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (name.isNotBlank() && trigger.isNotBlank()) {
                        val finalDesc = if (desc.isBlank()) "নাঈমের কাস্টম তৈরি করা স্বয়ংক্রিয় ফিচার" else desc
                        onAdd(name, trigger, finalDesc, response)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = NeonCyan, contentColor = ObsidianBlack)
            ) {
                Text("যুক্ত ও আপডেট করুন", fontWeight = FontWeight.Bold)
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("বাতিল", color = TextSecondary)
            }
        }
    )
}
