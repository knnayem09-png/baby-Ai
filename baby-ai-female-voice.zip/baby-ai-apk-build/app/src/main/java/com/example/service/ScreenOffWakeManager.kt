package com.example.service

import android.content.Context
import android.os.Build
import android.os.PowerManager
import android.os.VibrationEffect
import android.os.Vibrator
import android.os.VibratorManager
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

class ScreenOffWakeManager(private val context: Context) {

    private val powerManager = context.getSystemService(Context.POWER_SERVICE) as? PowerManager
    private var wakeLock: PowerManager.WakeLock? = null

    private val _isWakeListeningEnabled = MutableStateFlow(true)
    val isWakeListeningEnabled: StateFlow<Boolean> = _isWakeListeningEnabled.asStateFlow()

    init {
        try {
            wakeLock = powerManager?.newWakeLock(
                PowerManager.PARTIAL_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP,
                "BabyAI:VoiceWakeLockTag"
            )
        } catch (e: Exception) {
            Log.w("ScreenOffWakeManager", "WakeLock init: ${e.message}")
        }
    }

    fun toggleWakeListening(enabled: Boolean) {
        _isWakeListeningEnabled.value = enabled
        if (enabled) {
            try {
                if (wakeLock?.isHeld == false) {
                    wakeLock?.acquire(10 * 60 * 1000L) // 10 minutes temporary wake session
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        } else {
            try {
                if (wakeLock?.isHeld == true) {
                    wakeLock?.release()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }
    }

    fun triggerWakeup(onWakeAction: () -> Unit) {
        // 1. Wake screen up
        try {
            val screenWakeLock = powerManager?.newWakeLock(
                PowerManager.SCREEN_BRIGHT_WAKE_LOCK or PowerManager.ACQUIRE_CAUSES_WAKEUP or PowerManager.ON_AFTER_RELEASE,
                "BabyAI:ScreenBrightWake"
            )
            screenWakeLock?.acquire(3000L)
        } catch (e: Exception) {
            e.printStackTrace()
        }

        // 2. Sweet double-pulse haptic vibration (Heartbeat effect)
        try {
            val vibrator = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.S) {
                val vibratorManager = context.getSystemService(Context.VIBRATOR_MANAGER_SERVICE) as VibratorManager
                vibratorManager.defaultVibrator
            } else {
                @Suppress("DEPRECATION")
                context.getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val timings = longArrayOf(0, 150, 100, 200)
                val amplitudes = intArrayOf(0, 255, 0, 255)
                vibrator.vibrate(VibrationEffect.createWaveform(timings, amplitudes, -1))
            } else {
                @Suppress("DEPRECATION")
                vibrator.vibrate(longArrayOf(0, 150, 100, 200), -1)
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

        onWakeAction()
    }
}
