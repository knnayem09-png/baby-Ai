# Baby AI Android project — APK build

This is an Android/Jetpack Compose project exported from Google AI Studio. The GitHub Actions workflow in `.github/workflows/build-apk.yml` builds a **debug APK** automatically.

## Build the APK using GitHub on your phone

1. Create a new GitHub repository and upload all files and folders from this project (including the hidden `.github` folder).
2. Open the repository's **Actions** tab.
3. Select **Build Baby AI APK** and tap **Run workflow** (or push to `main`/`master`).
4. Wait for the workflow to finish successfully.
5. Open the completed workflow run and download **baby-ai-debug-apk** under **Artifacts**.
6. Extract the downloaded artifact ZIP, then install the `.apk` on your Android phone. Android may ask you to allow installation from that source.

## Important notes

- This repository does not include a built APK yet. GitHub Actions creates it after you upload the project and the workflow succeeds.
- AI features that call Gemini may need your own Gemini API key. Configure `GEMINI_API_KEY` securely in the project/AI Studio secrets workflow as appropriate; do not publish a real API key in a public repository.
- The workflow creates a debug signing key for this build. This APK is for testing/sideloading, not a Play Store release. A Play Store release needs a separately managed private signing key.
- If the build fails, open the workflow run and inspect the first Gradle error; SDK or plugin versions may need adjustment.

## Original project notes

<div align="center">
<img width="1200" height="475" alt="GHBanner" src="https://ai.google.dev/static/site-assets/images/share-ais-513315318.png" />
</div>

# Run and deploy your AI Studio app

This contains everything you need to run your app locally.

View your app in AI Studio: https://ai.studio/apps/bbcd899b-2963-44ec-833d-75a6ad3b0fac

## Run Locally

**Prerequisites:**  [Android Studio](https://developer.android.com/studio)


1. Open Android Studio
2. Select **Open** and choose the directory containing this project
3. Allow Android Studio to fix any incompatibilities as it imports the project.
4. Create a file named `.env` in the project directory and set `GEMINI_API_KEY` in that file to your Gemini API key (see `.env.example` for an example)
5. Remove this line from the app's `build.gradle.kts` file: `signingConfig = signingConfigs.getByName("debugConfig")`
6. Run the app on an emulator or physical device
7. If you have already published your app in AI Studio, please [request upload key reset](https://support.google.com/googleplay/android-developer/answer/9842756#zippy=%2Crequest-an-upload-key-reset) in Google Play Console.
